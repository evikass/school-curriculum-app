import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { LessonItem } from '../data/types';
import { useApp } from '../context/AppContext';

const { width } = Dimensions.get('window');

interface Props {
  route: { params: { lesson: LessonItem; lessonIndex: number } };
  navigation: any;
}

export default function LessonScreen({ route, navigation }: Props) {
  const { lesson, lessonIndex } = route.params;
  const [showTasks, setShowTasks] = useState(false);
  const { addXP } = useApp();

  const handleComplete = () => {
    addXP(10);
    navigation.goBack();
  };

  // Форматирование Markdown-подобного текста
  const formatText = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, index) => {
      // Заголовки
      if (line.startsWith('### ')) {
        return (
          <Text key={index} style={styles.h3}>
            {line.replace('### ', '')}
          </Text>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <Text key={index} style={styles.h2}>
            {line.replace('## ', '')}
          </Text>
        );
      }
      // Пункты списка
      if (line.startsWith('• ') || line.startsWith('- ')) {
        return (
          <View key={index} style={styles.listItem}>
            <Text style={styles.bullet}>•</Text>
            <Text style={styles.listText}>{line.substring(2)}</Text>
          </View>
        );
      }
      // Нумерованный список
      if (/^\d+\.\s/.test(line)) {
        return (
          <View key={index} style={styles.listItem}>
            <Text style={styles.numberBullet}>{line.match(/^\d+\./)?.[0]} </Text>
            <Text style={styles.listText}>{line.replace(/^\d+\.\s/, '')}</Text>
          </View>
        );
      }
      // Пустая строка
      if (!line.trim()) {
        return <View key={index} style={styles.spacer} />;
      }
      // Обычный текст
      return (
        <Text key={index} style={styles.paragraph}>
          {line}
        </Text>
      );
    });
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.closeButtonText}>✕</Text>
            </TouchableOpacity>
            <Text style={styles.lessonTitle} numberOfLines={2}>
              {lesson.title}
            </Text>
          </View>

          {/* Content */}
          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            {/* Theory */}
            <View style={styles.theoryCard}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardIcon}>📖</Text>
                <Text style={styles.cardTitle}>Теория</Text>
              </View>
              <View style={styles.cardContent}>
                {formatText(lesson.description)}
              </View>
            </View>

            {/* Examples */}
            {lesson.examples && lesson.examples.length > 0 && (
              <View style={styles.examplesCard}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardIcon}>💡</Text>
                  <Text style={styles.cardTitle}>Примеры</Text>
                </View>
                {lesson.examples.map((example, index) => (
                  <View key={index} style={styles.exampleItem}>
                    <Text style={styles.exampleText}>• {example}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Facts */}
            {lesson.facts && lesson.facts.length > 0 && (
              <View style={styles.factsCard}>
                <View style={styles.cardHeader}>
                  <Text style={styles.cardIcon}>🎯</Text>
                  <Text style={styles.cardTitle}>Интересные факты</Text>
                </View>
                {lesson.facts.map((fact, index) => (
                  <View key={index} style={styles.factItem}>
                    <Text style={styles.factNumber}>{index + 1}</Text>
                    <Text style={styles.factText}>{fact}</Text>
                  </View>
                ))}
              </View>
            )}

            {/* Tasks */}
            <View style={styles.tasksCard}>
              <TouchableOpacity
                style={styles.cardHeader}
                onPress={() => setShowTasks(!showTasks)}
              >
                <Text style={styles.cardIcon}>✏️</Text>
                <Text style={styles.cardTitle}>Задания</Text>
                <Text style={styles.expandIcon}>{showTasks ? '▼' : '▶'}</Text>
              </TouchableOpacity>
              {showTasks && (
                <View style={styles.tasksList}>
                  {lesson.tasks.map((task, index) => (
                    <View key={index} style={styles.taskItem}>
                      <View style={styles.taskCheckbox} />
                      <Text style={styles.taskText}>{task}</Text>
                    </View>
                  ))}
                </View>
              )}
            </View>

            {/* Complete Button */}
            <TouchableOpacity
              style={styles.completeButton}
              onPress={handleComplete}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.completeGradient}
              >
                <Text style={styles.completeIcon}>✓</Text>
                <Text style={styles.completeText}>Завершить урок</Text>
              </LinearGradient>
            </TouchableOpacity>

            {/* Spacer for bottom */}
            <View style={styles.bottomSpacer} />
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 8,
    paddingBottom: 16,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  closeButtonText: {
    color: '#FFF',
    fontSize: 18,
  },
  lessonTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
  },
  scrollView: {
    flex: 1,
  },
  theoryCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  cardIcon: {
    fontSize: 24,
    marginRight: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
    flex: 1,
  },
  cardContent: {
    padding: 16,
  },
  h2: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FDE68A',
    marginBottom: 12,
    marginTop: 8,
  },
  h3: {
    fontSize: 18,
    fontWeight: '600',
    color: '#C4B5FD',
    marginBottom: 8,
    marginTop: 12,
  },
  paragraph: {
    fontSize: 16,
    color: '#E5E7EB',
    lineHeight: 24,
  },
  listItem: {
    flexDirection: 'row',
    marginBottom: 8,
    paddingRight: 8,
  },
  bullet: {
    color: '#C4B5FD',
    fontSize: 16,
    marginRight: 8,
    width: 16,
  },
  numberBullet: {
    color: '#C4B5FD',
    fontSize: 16,
    fontWeight: '600',
  },
  listText: {
    flex: 1,
    fontSize: 16,
    color: '#E5E7EB',
    lineHeight: 24,
  },
  spacer: {
    height: 8,
  },
  examplesCard: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  exampleItem: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  exampleText: {
    fontSize: 16,
    color: '#6EE7B7',
    lineHeight: 24,
  },
  factsCard: {
    backgroundColor: 'rgba(251, 191, 36, 0.15)',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  factItem: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'flex-start',
  },
  factNumber: {
    color: '#FDE68A',
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 12,
  },
  factText: {
    flex: 1,
    fontSize: 16,
    color: '#FDE68A',
    lineHeight: 24,
  },
  tasksCard: {
    backgroundColor: 'rgba(139, 92, 246, 0.15)',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
  },
  expandIcon: {
    color: '#C4B5FD',
    fontSize: 12,
  },
  tasksList: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  taskCheckbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 2,
    borderColor: '#C4B5FD',
    marginRight: 12,
    marginTop: 2,
  },
  taskText: {
    flex: 1,
    fontSize: 16,
    color: '#E5E7EB',
    lineHeight: 24,
  },
  completeButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
  },
  completeGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  completeIcon: {
    color: '#FFF',
    fontSize: 20,
    marginRight: 8,
  },
  completeText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bottomSpacer: {
    height: 40,
  },
});
