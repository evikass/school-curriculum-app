import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../context/AppContext';

interface Props {
  navigation: any;
}

const GAMES = [
  { id: 'memory', title: 'Найди пару', icon: '🧠', color: '#8B5CF6' },
  { id: 'quiz', title: 'Викторина', icon: '❓', color: '#3B82F6' },
  { id: 'math', title: 'Быстрый счёт', icon: '🔢', color: '#10B981' },
  { id: 'words', title: 'Собери слово', icon: '📝', color: '#F59E0B' },
];

export default function GamesScreen({ navigation }: Props) {
  const { profile, addXP } = useApp();
  const [selectedGame, setSelectedGame] = useState<string | null>(null);
  const [quizVisible, setQuizVisible] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [quizEnded, setQuizEnded] = useState(false);

  // Простые вопросы для викторины
  const quizQuestions = [
    {
      question: 'Сколько будет 2 + 2?',
      options: ['3', '4', '5', '6'],
      correct: 1,
    },
    {
      question: 'Сколько дней в неделе?',
      options: ['5', '6', '7', '8'],
      correct: 2,
    },
    {
      question: 'Какого цвета нет в радуге?',
      options: ['Красный', 'Зелёный', 'Розовый', 'Синий'],
      correct: 2,
    },
    {
      question: 'Сколько лап у кошки?',
      options: ['2', '3', '4', '5'],
      correct: 2,
    },
    {
      question: 'Какой месяц первый в году?',
      options: ['Февраль', 'Январь', 'Декабрь', 'Март'],
      correct: 1,
    },
  ];

  const handleGameSelect = (gameId: string) => {
    if (gameId === 'quiz') {
      setCurrentQuestion(0);
      setScore(0);
      setQuizEnded(false);
      setQuizVisible(true);
    } else {
      setSelectedGame(gameId);
    }
  };

  const handleAnswer = (answerIndex: number) => {
    if (answerIndex === quizQuestions[currentQuestion].correct) {
      setScore(score + 1);
      addXP(5);
    }

    if (currentQuestion < quizQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setQuizEnded(true);
      if (score + 1 === quizQuestions.length) {
        addXP(20); // Бонус за идеальную игру
      }
    }
  };

  const renderQuiz = () => (
    <Modal visible={quizVisible} animationType="slide" transparent>
      <View style={styles.modalOverlay}>
        <View style={styles.quizContainer}>
          {!quizEnded ? (
            <>
              <Text style={styles.quizProgress}>
                Вопрос {currentQuestion + 1} из {quizQuestions.length}
              </Text>
              <Text style={styles.quizQuestion}>
                {quizQuestions[currentQuestion].question}
              </Text>
              {quizQuestions[currentQuestion].options.map((option, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.quizOption}
                  onPress={() => handleAnswer(index)}
                >
                  <Text style={styles.quizOptionText}>{option}</Text>
                </TouchableOpacity>
              ))}
            </>
          ) : (
            <>
              <Text style={styles.quizEndTitle}>Результат</Text>
              <Text style={styles.quizEndScore}>
                {score} из {quizQuestions.length}
              </Text>
              <Text style={styles.quizEndEmoji}>
                {score === quizQuestions.length ? '🏆' : score >= 3 ? '⭐' : '💪'}
              </Text>
              <TouchableOpacity
                style={styles.quizCloseButton}
                onPress={() => setQuizVisible(false)}
              >
                <Text style={styles.quizCloseText}>Закрыть</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </Modal>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>🎮 Мини-игры</Text>
            <Text style={styles.headerSubtitle}>
              Зарабатывай XP играя!
            </Text>
          </View>

          {/* Stats */}
          <View style={styles.statsBar}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>⭐ {profile.xp} XP</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>🎯 Уровень {profile.level}</Text>
            </View>
          </View>

          {/* Games Grid */}
          <ScrollView style={styles.scrollView}>
            <Text style={styles.sectionTitle}>Выбери игру</Text>
            <View style={styles.gamesGrid}>
              {GAMES.map((game) => (
                <TouchableOpacity
                  key={game.id}
                  style={[styles.gameCard, { borderColor: game.color }]}
                  onPress={() => handleGameSelect(game.id)}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']}
                    style={styles.gameGradient}
                  >
                    <Text style={styles.gameIcon}>{game.icon}</Text>
                    <Text style={styles.gameTitle}>{game.title}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </View>

            {/* Coming Soon */}
            <View style={styles.comingSoonCard}>
              <Text style={styles.comingSoonText}>
                🚧 Скоро появятся новые игры!
              </Text>
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
      {renderQuiz()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    paddingTop: 16,
    paddingBottom: 12,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#C4B5FD',
    marginTop: 4,
  },
  statsBar: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    paddingVertical: 12,
    marginBottom: 20,
    gap: 32,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 16,
    color: '#FDE68A',
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 16,
  },
  gamesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  gameCard: {
    width: '48%',
    aspectRatio: 1,
    marginBottom: 16,
    borderRadius: 20,
    borderWidth: 2,
    overflow: 'hidden',
  },
  gameGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameIcon: {
    fontSize: 48,
    marginBottom: 8,
  },
  gameTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFF',
    textAlign: 'center',
  },
  comingSoonCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginTop: 8,
  },
  comingSoonText: {
    color: '#C4B5FD',
    fontSize: 16,
  },
  // Quiz Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  quizContainer: {
    backgroundColor: '#1E1B4B',
    borderRadius: 24,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  quizProgress: {
    color: '#C4B5FD',
    fontSize: 14,
    marginBottom: 16,
  },
  quizQuestion: {
    color: '#FFF',
    fontSize: 22,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 24,
  },
  quizOption: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  quizOptionText: {
    color: '#FFF',
    fontSize: 18,
    textAlign: 'center',
  },
  quizEndTitle: {
    color: '#FFF',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  quizEndScore: {
    color: '#FDE68A',
    fontSize: 48,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  quizEndEmoji: {
    fontSize: 64,
    textAlign: 'center',
    marginVertical: 24,
  },
  quizCloseButton: {
    backgroundColor: '#8B5CF6',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  quizCloseText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
