import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../context/AppContext';
import { RANKS, ACHIEVEMENTS } from '../data/constants';
import { getRankByLevel, xpForNextLevel } from '../data/constants';

export default function ProfileScreen({ navigation }: any) {
  const { profile } = useApp();
  const currentRank = getRankByLevel(profile.level);
  const xpToNext = xpForNextLevel(profile.level + 1);
  const progress = (profile.xp / xpToNext) * 100;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Profile Card */}
            <View style={styles.profileCard}>
              <LinearGradient
                colors={['rgba(139, 92, 246, 0.3)', 'rgba(139, 92, 246, 0.1)']}
                style={styles.profileGradient}
              >
                <Text style={styles.avatarIcon}>👤</Text>
                <Text style={styles.userName}>{profile.name}</Text>
                <View style={styles.rankBadge}>
                  <Text style={styles.rankIcon}>{currentRank.icon}</Text>
                  <Text style={styles.rankName}>{currentRank.name}</Text>
                </View>
              </LinearGradient>
            </View>

            {/* Level Progress */}
            <View style={styles.progressCard}>
              <View style={styles.levelHeader}>
                <Text style={styles.levelNumber}>Уровень {profile.level}</Text>
                <Text style={styles.xpCount}>{profile.xp} XP</Text>
              </View>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${progress}%` }]} />
              </View>
              <Text style={styles.xpToNext}>
                До следующего уровня: {xpToNext - profile.xp} XP
              </Text>
            </View>

            {/* Stats */}
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statEmoji}>🔥</Text>
                <Text style={styles.statNumber}>{profile.streak}</Text>
                <Text style={styles.statLabel}>дней подряд</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statEmoji}>⭐</Text>
                <Text style={styles.statNumber}>{profile.xp}</Text>
                <Text style={styles.statLabel}>очков XP</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statEmoji}>📚</Text>
                <Text style={styles.statNumber}>{profile.achievements.length}</Text>
                <Text style={styles.statLabel}>достижений</Text>
              </View>
            </View>

            {/* Achievements */}
            <View style={styles.achievementsSection}>
              <Text style={styles.sectionTitle}>Достижения</Text>
              <View style={styles.achievementsGrid}>
                {ACHIEVEMENTS.map((achievement) => {
                  const unlocked = profile.achievements.includes(achievement.id);
                  return (
                    <View
                      key={achievement.id}
                      style={[
                        styles.achievementBadge,
                        !unlocked && styles.achievementLocked,
                      ]}
                    >
                      <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                      <Text style={styles.achievementName}>{achievement.name}</Text>
                      {!unlocked && <Text style={styles.lockedIcon}>🔒</Text>}
                    </View>
                  );
                })}
              </View>
            </View>

            {/* Ranks Info */}
            <View style={styles.ranksSection}>
              <Text style={styles.sectionTitle}>Звания</Text>
              {RANKS.map((rank, index) => {
                const achieved = profile.level >= rank.minLevel;
                return (
                  <View
                    key={rank.name}
                    style={[
                      styles.rankItem,
                      achieved && styles.rankItemAchieved,
                    ]}
                  >
                    <Text style={styles.rankItemIcon}>{rank.icon}</Text>
                    <View style={styles.rankItemInfo}>
                      <Text style={styles.rankItemName}>{rank.name}</Text>
                      <Text style={styles.rankItemLevel}>
                        Уровень {rank.minLevel}+
                      </Text>
                    </View>
                    {achieved && <Text style={styles.checkMark}>✓</Text>}
                  </View>
                );
              })}
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  profileCard: {
    borderRadius: 24,
    overflow: 'hidden',
    marginTop: 16,
    marginBottom: 20,
  },
  profileGradient: {
    alignItems: 'center',
    paddingVertical: 32,
    paddingHorizontal: 24,
  },
  avatarIcon: {
    fontSize: 80,
    marginBottom: 12,
  },
  userName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 8,
  },
  rankBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  rankIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  rankName: {
    color: '#FDE68A',
    fontSize: 18,
    fontWeight: '600',
  },
  progressCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  levelHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  levelNumber: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  xpCount: {
    color: '#FDE68A',
    fontSize: 18,
    fontWeight: '600',
  },
  progressBar: {
    height: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 6,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#8B5CF6',
    borderRadius: 6,
  },
  xpToNext: {
    color: '#C4B5FD',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    paddingVertical: 20,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  statEmoji: {
    fontSize: 32,
    marginBottom: 8,
  },
  statNumber: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statLabel: {
    color: '#C4B5FD',
    fontSize: 12,
    marginTop: 4,
  },
  achievementsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#FFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  achievementsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  achievementBadge: {
    width: '48%',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  achievementLocked: {
    opacity: 0.5,
  },
  achievementIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  achievementName: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  lockedIcon: {
    position: 'absolute',
    top: 8,
    right: 8,
    fontSize: 16,
  },
  ranksSection: {
    marginBottom: 40,
  },
  rankItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
  },
  rankItemAchieved: {
    backgroundColor: 'rgba(139, 92, 246, 0.3)',
  },
  rankItemIcon: {
    fontSize: 28,
    marginRight: 16,
  },
  rankItemInfo: {
    flex: 1,
  },
  rankItemName: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  rankItemLevel: {
    color: '#C4B5FD',
    fontSize: 14,
    marginTop: 2,
  },
  checkMark: {
    color: '#10B981',
    fontSize: 24,
    fontWeight: 'bold',
  },
});
