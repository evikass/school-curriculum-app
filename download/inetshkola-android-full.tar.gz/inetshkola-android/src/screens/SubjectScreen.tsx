import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  LayoutAnimation,
  Platform,
  UIManager,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Grade, Subject, Topic } from '../data/types';
import { useApp } from '../context/AppContext';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

interface Props {
  route: { params: { grade: Grade; subject: Subject } };
  navigation: any;
}

export default function SubjectScreen({ route, navigation }: Props) {
  const { grade, subject } = route.params;
  const [expandedTopic, setExpandedTopic] = useState<string | null>(null);
  const { getProgress } = useApp();

  const toggleTopic = (topicName: string) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedTopic(expandedTopic === topicName ? null : topicName);
  };

  const isLessonCompleted = (lessonIndex: number): boolean => {
    const progress = getProgress(grade.id, subject.id);
    return progress.some(p => p.lessonIndex === lessonIndex && p.completed);
  };

  const renderTopic = (topic: Topic, topicIndex: number) => {
    const isExpanded = expandedTopic === topic.topic;
    const totalLessons = topic.lessons.length;

    return (
      <View key={topic.topic} style={styles.topicContainer}>
        <TouchableOpacity
          style={styles.topicHeader}
          onPress={() => toggleTopic(topic.topic)}
          activeOpacity={0.7}
        >
          <View style={styles.topicInfo}>
            <Text style={styles.topicNumber}>{topicIndex + 1}</Text>
            <View style={styles.topicTextContainer}>
              <Text style={styles.topicTitle}>{topic.topic}</Text>
              <Text style={styles.lessonCount}>{totalLessons} уроков</Text>
            </View>
          </View>
          <Text style={styles.expandIcon}>{isExpanded ? '▼' : '▶'}</Text>
        </TouchableOpacity>

        {isExpanded && (
          <View style={styles.lessonsList}>
            {topic.lessons.map((lesson, lessonIndex) => {
              const globalLessonIndex = topicIndex * 100 + lessonIndex;
              const completed = isLessonCompleted(globalLessonIndex);

              return (
                <TouchableOpacity
                  key={lessonIndex}
                  style={styles.lessonItem}
                  onPress={() => navigation.navigate('Lesson', {
                    grade,
                    subject,
                    lesson,
                    lessonIndex: globalLessonIndex,
                  })}
                  activeOpacity={0.7}
                >
                  <View style={styles.lessonLeft}>
                    <View style={[
                      styles.lessonNumberCircle,
                      completed && styles.lessonNumberCircleCompleted
                    ]}>
                      {completed ? (
                        <Text style={styles.checkIcon}>✓</Text>
                      ) : (
                        <Text style={styles.lessonNumberText}>{lessonIndex + 1}</Text>
                      )}
                    </View>
                    <Text style={styles.lessonTitle} numberOfLines={2}>
                      {lesson.title}
                    </Text>
                  </View>
                  <Text style={styles.arrowIcon}>→</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.backButtonText}>← Назад</Text>
            </TouchableOpacity>
            <View style={styles.headerContent}>
              <Text style={styles.subjectIcon}>{subject.icon}</Text>
              <Text style={styles.subjectTitle}>{subject.title}</Text>
            </View>
          </View>

          {/* Topics */}
          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionTitle}>Темы</Text>
            {subject.topics.map((topic, index) => renderTopic(topic, index))}
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    paddingTop: 8,
    paddingBottom: 16,
    alignItems: 'center',
  },
  backButton: {
    position: 'absolute',
    left: 0,
    top: 8,
    zIndex: 10,
  },
  backButtonText: {
    color: '#C4B5FD',
    fontSize: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 32,
  },
  subjectIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  subjectTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFF',
  },
  scrollView: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 16,
  },
  topicContainer: {
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    overflow: 'hidden',
  },
  topicHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  topicInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  topicNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FDE68A',
    marginRight: 16,
    width: 32,
  },
  topicTextContainer: {
    flex: 1,
  },
  topicTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFF',
    marginBottom: 4,
  },
  lessonCount: {
    fontSize: 14,
    color: '#C4B5FD',
  },
  expandIcon: {
    color: '#C4B5FD',
    fontSize: 14,
  },
  lessonsList: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  lessonItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  lessonLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  lessonNumberCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  lessonNumberCircleCompleted: {
    backgroundColor: '#10B981',
  },
  checkIcon: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  lessonNumberText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: '600',
  },
  lessonTitle: {
    color: '#FFF',
    fontSize: 16,
    flex: 1,
  },
  arrowIcon: {
    color: '#C4B5FD',
    fontSize: 18,
    marginLeft: 8,
  },
});
