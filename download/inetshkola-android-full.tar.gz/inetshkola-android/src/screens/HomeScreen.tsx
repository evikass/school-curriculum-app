import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { GRADES } from '../data/constants';
import { useApp } from '../context/AppContext';

export default function HomeScreen({ navigation }: any) {
  const { profile } = useApp();

  // Цвета для разных классов
  const getGradeColors = (gradeId: number): [string, string] => {
    const colorPairs: { [key: number]: [string, string] } = {
      0: ['#FF6B6B', '#FF8E53'],   // Подготовительный - тёплый оранжевый
      1: ['#6366F1', '#8B5CF6'],   // 1 класс - фиолетовый
      2: ['#10B981', '#34D399'],   // 2 класс - зелёный
      3: ['#3B82F6', '#60A5FA'],   // 3 класс - синий
      4: ['#F59E0B', '#FBBF24'],   // 4 класс - жёлтый
      5: ['#EC4899', '#F472B6'],   // 5 класс - розовый
      6: ['#14B8A6', '#2DD4BF'],   // 6 класс - бирюзовый
      7: ['#8B5CF6', '#A78BFA'],   // 7 класс - лиловый
      8: ['#EF4444', '#F87171'],   // 8 класс - красный
      9: ['#F97316', '#FB923C'],   // 9 класс - оранжевый
      10: ['#06B6D4', '#22D3EE'],  // 10 класс - голубой
      11: ['#8B5CF6', '#C084FC'],  // 11 класс - фиолетовый
    };
    return colorPairs[gradeId] || ['#6366F1', '#8B5CF6'];
  };

  const renderGradeCard = (grade: typeof GRADES[0]) => {
    const subjectCount = grade.subjects?.length || 0;
    const isAvailable = subjectCount > 0;

    return (
      <TouchableOpacity
        key={grade.id}
        style={[styles.gradeCard, !isAvailable && styles.gradeCardLocked]}
        onPress={() => isAvailable && navigation.navigate('Grade', { grade })}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={getGradeColors(grade.id)}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradeGradient}
        >
          <Text style={styles.gradeIcon}>{grade.icon}</Text>
          <Text style={styles.gradeTitle}>{grade.title}</Text>
          {isAvailable && (
            <Text style={styles.subjectCount}>{subjectCount} предметов</Text>
          )}
          {!isAvailable && (
            <View style={styles.lockedOverlay}>
              <Text style={styles.lockedText}>🔒 Скоро</Text>
            </View>
          )}
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity>
              <Text style={styles.appTitle}>ИНЕТШКОЛА</Text>
            </TouchableOpacity>
            <Text style={styles.appSubtitle}>Интерактивная школьная программа</Text>
          </View>

          {/* Profile Stats */}
          <View style={styles.statsBar}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>⭐ {profile.xp} XP</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>🎯 Уровень {profile.level}</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>🔥 {profile.streak} дней</Text>
            </View>
          </View>

          {/* Grades Grid */}
          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionTitle}>Выбери класс</Text>
            <View style={styles.gradesGrid}>
              {GRADES.map(renderGradeCard)}
            </View>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    alignItems: 'center',
    paddingTop: 16,
    paddingBottom: 12,
  },
  appTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FCD34D',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  appSubtitle: {
    fontSize: 14,
    color: '#C4B5FD',
    marginTop: 4,
  },
  statsBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    paddingVertical: 12,
    marginBottom: 16,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 14,
    color: '#FDE68A',
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 16,
  },
  gradesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingBottom: 20,
  },
  gradeCard: {
    width: '48%',
    aspectRatio: 1,
    marginBottom: 16,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  gradeCardLocked: {
    opacity: 0.6,
  },
  gradeGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  gradeIcon: {
    fontSize: 48,
    marginBottom: 8,
  },
  gradeTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
    textAlign: 'center',
  },
  subjectCount: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 4,
  },
  lockedOverlay: {
    position: 'absolute',
    bottom: 12,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  lockedText: {
    color: '#FFF',
    fontSize: 12,
  },
});
