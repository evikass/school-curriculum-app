import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Grade, Subject } from '../data/types';
import { useApp } from '../context/AppContext';

interface Props {
  route: { params: { grade: Grade } };
  navigation: any;
}

export default function GradeScreen({ route, navigation }: Props) {
  const { grade } = route.params;
  const { getProgress } = useApp();

  const getProgressPercentage = (subject: Subject): number => {
    const progress = getProgress(grade.id, subject.id);
    if (!progress.length) return 0;
    const totalLessons = subject.topics.reduce((acc, t) => acc + t.lessons.length, 0);
    const completed = progress.filter(p => p.completed).length;
    return Math.round((completed / totalLessons) * 100);
  };

  const renderSubjectCard = (subject: Subject) => {
    const progressPercent = getProgressPercentage(subject);

    return (
      <TouchableOpacity
        key={subject.id}
        style={styles.subjectCard}
        onPress={() => navigation.navigate('Subject', { grade, subject })}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['rgba(255,255,255,0.15)', 'rgba(255,255,255,0.05)']}
          style={styles.subjectGradient}
        >
          <View style={styles.subjectHeader}>
            <Text style={styles.subjectIcon}>{subject.icon}</Text>
            <View style={styles.subjectInfo}>
              <Text style={styles.subjectTitle}>{subject.title}</Text>
              <Text style={styles.subjectTopics}>
                {subject.topics.length} тем
              </Text>
            </View>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${progressPercent}%`, backgroundColor: subject.color }
                ]}
              />
            </View>
            <Text style={styles.progressText}>{progressPercent}%</Text>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        colors={['#1E1B4B', '#312E81', '#4C1D95']}
        style={styles.background}
      >
        <SafeAreaView style={styles.safeArea}>
          {/* Header */}
          <View style={styles.header}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.backButtonText}>← Назад</Text>
            </TouchableOpacity>
            <View style={styles.headerContent}>
              <Text style={styles.gradeIcon}>{grade.icon}</Text>
              <Text style={styles.gradeTitle}>{grade.title}</Text>
            </View>
          </View>

          {/* Subjects List */}
          <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionTitle}>Предметы</Text>

            {grade.subjects.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyIcon}>📚</Text>
                <Text style={styles.emptyText}>
                  Предметы для этого класса скоро будут добавлены!
                </Text>
              </View>
            ) : (
              grade.subjects.map(renderSubjectCard)
            )}
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    paddingTop: 8,
    paddingBottom: 16,
  },
  backButton: {
    marginBottom: 12,
  },
  backButtonText: {
    color: '#C4B5FD',
    fontSize: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  gradeIcon: {
    fontSize: 36,
    marginRight: 12,
  },
  gradeTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
  },
  scrollView: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 16,
  },
  subjectCard: {
    borderRadius: 16,
    marginBottom: 12,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  subjectGradient: {
    padding: 16,
  },
  subjectHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  subjectIcon: {
    fontSize: 40,
    marginRight: 16,
  },
  subjectInfo: {
    flex: 1,
  },
  subjectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    marginBottom: 4,
  },
  subjectTopics: {
    fontSize: 14,
    color: '#C4B5FD',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  progressBar: {
    flex: 1,
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    marginLeft: 12,
    color: '#FDE68A',
    fontSize: 14,
    fontWeight: '600',
    minWidth: 40,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  emptyText: {
    fontSize: 16,
    color: '#C4B5FD',
    textAlign: 'center',
  },
});
