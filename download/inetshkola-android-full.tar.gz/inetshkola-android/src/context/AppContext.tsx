import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { UserProfile, UserProgress } from '../data/types';
import { calculateLevel, getRankByLevel, XP_REWARDS } from '../data/constants';

interface AppContextType {
  profile: UserProfile;
  addXP: (amount: number) => void;
  completeLesson: (grade: number, subject: string, lessonIndex: number, score: number) => void;
  getProgress: (grade: number, subject: string) => UserProgress[];
  unlockAchievement: (id: string) => void;
  updateStreak: () => void;
  isLoading: boolean;
}

const defaultProfile: UserProfile = {
  name: 'Ученик',
  xp: 0,
  level: 1,
  achievements: [],
  streak: 0,
};

const STORAGE_KEYS = {
  PROFILE: '@inetshkola_profile',
  PROGRESS: '@inetshkola_progress',
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<UserProfile>(defaultProfile);
  const [progress, setProgress] = useState<UserProgress[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Загрузка данных при старте
  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const savedProfile = await AsyncStorage.getItem(STORAGE_KEYS.PROFILE);
      const savedProgress = await AsyncStorage.getItem(STORAGE_KEYS.PROGRESS);
      
      if (savedProfile) {
        setProfile(JSON.parse(savedProfile));
      }
      if (savedProgress) {
        setProgress(JSON.parse(savedProgress));
      }
    } catch (error) {
      console.log('Error loading profile:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveProfile = async (newProfile: UserProfile) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(newProfile));
    } catch (error) {
      console.log('Error saving profile:', error);
    }
  };

  const saveProgress = async (newProgress: UserProgress[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.PROGRESS, JSON.stringify(newProgress));
    } catch (error) {
      console.log('Error saving progress:', error);
    }
  };

  const addXP = (amount: number) => {
    setProfile(prev => {
      const newXP = prev.xp + amount;
      const newLevel = calculateLevel(newXP);
      const updated = { ...prev, xp: newXP, level: newLevel };
      saveProfile(updated);
      return updated;
    });
  };

  const completeLesson = (grade: number, subject: string, lessonIndex: number, score: number) => {
    const progressItem: UserProgress = {
      grade,
      subject,
      lessonIndex,
      completed: true,
      score,
    };

    setProgress(prev => {
      const existing = prev.findIndex(
        p => p.grade === grade && p.subject === subject && p.lessonIndex === lessonIndex
      );
      let updated: UserProgress[];
      if (existing >= 0) {
        updated = [...prev];
        updated[existing] = progressItem;
      } else {
        updated = [...prev, progressItem];
      }
      saveProgress(updated);
      return updated;
    });

    addXP(XP_REWARDS.COMPLETE_LESSON);
  };

  const getProgress = (grade: number, subject: string): UserProgress[] => {
    return progress.filter(p => p.grade === grade && p.subject === subject);
  };

  const unlockAchievement = (id: string) => {
    setProfile(prev => {
      if (prev.achievements.includes(id)) return prev;
      const updated = { ...prev, achievements: [...prev.achievements, id] };
      saveProfile(updated);
      return updated;
    });
  };

  const updateStreak = () => {
    setProfile(prev => {
      const updated = { ...prev, streak: prev.streak + 1 };
      saveProfile(updated);
      return updated;
    });
    addXP(XP_REWARDS.STREAK_BONUS);
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        addXP,
        completeLesson,
        getProgress,
        unlockAchievement,
        updateStreak,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
