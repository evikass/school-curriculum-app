// Типы данных для приложения ИНЕТШКОЛА

export interface LessonItem {
  title: string;
  description: string;
  tasks: string[];
  examples?: string[];
  facts?: string[];
}

export interface Topic {
  topic: string;
  lessons: LessonItem[];
}

export interface Subject {
  id: string;
  title: string;
  icon: string;
  color: string;
  topics: Topic[];
}

export interface Grade {
  id: number;
  title: string;
  icon: string;
  subjects: Subject[];
}

export interface QuizQuestion {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
}

export interface GameData {
  id: string;
  title: string;
  subject: string;
  questions: QuizQuestion[];
}

export interface UserProgress {
  grade: number;
  subject: string;
  lessonIndex: number;
  completed: boolean;
  score: number;
}

export interface UserProfile {
  name: string;
  xp: number;
  level: number;
  achievements: string[];
  streak: number;
}
