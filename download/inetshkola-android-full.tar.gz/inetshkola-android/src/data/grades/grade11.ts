import { Subject } from '../types';

export const grade11Russian: Subject = {
  id: 'russian',
  title: 'Русский язык',
  icon: '📖',
  color: '#EF4444',
  topics: [
    {
      topic: 'Основы русского языка',
      lessons: [
        {
          title: 'Введение в русский язык',
          description: 'Уроки по предмету "Русский язык" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Literature: Subject = {
  id: 'literature',
  title: 'Литература',
  icon: '📚',
  color: '#F97316',
  topics: [
    {
      topic: 'Основы литературы',
      lessons: [
        {
          title: 'Введение в литературу',
          description: 'Уроки по предмету "Литература" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Algebra: Subject = {
  id: 'algebra',
  title: 'Алгебра',
  icon: '📐',
  color: '#3B82F6',
  topics: [
    {
      topic: 'Основы алгебры',
      lessons: [
        {
          title: 'Введение в алгебру',
          description: 'Уроки по предмету "Алгебра" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Geometry: Subject = {
  id: 'geometry',
  title: 'Геометрия',
  icon: '📏',
  color: '#0EA5E9',
  topics: [
    {
      topic: 'Основы геометрии',
      lessons: [
        {
          title: 'Введение в геометрию',
          description: 'Уроки по предмету "Геометрия" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11History: Subject = {
  id: 'history',
  title: 'История',
  icon: '📜',
  color: '#92400E',
  topics: [
    {
      topic: 'Основы истории',
      lessons: [
        {
          title: 'Введение в историю',
          description: 'Уроки по предмету "История" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Geography: Subject = {
  id: 'geography',
  title: 'География',
  icon: '🗺️',
  color: '#059669',
  topics: [
    {
      topic: 'Основы географии',
      lessons: [
        {
          title: 'Введение в географию',
          description: 'Уроки по предмету "География" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Biology: Subject = {
  id: 'biology',
  title: 'Биология',
  icon: '🧬',
  color: '#10B981',
  topics: [
    {
      topic: 'Основы биологии',
      lessons: [
        {
          title: 'Введение в биологию',
          description: 'Уроки по предмету "Биология" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11English: Subject = {
  id: 'english',
  title: 'Английский',
  icon: '🔤',
  color: '#8B5CF6',
  topics: [
    {
      topic: 'Основы английского языка',
      lessons: [
        {
          title: 'Введение в английский язык',
          description: 'Уроки по предмету "Английский" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Informatics: Subject = {
  id: 'informatics',
  title: 'Информатика',
  icon: '💻',
  color: '#06B6D4',
  topics: [
    {
      topic: 'Основы информатики',
      lessons: [
        {
          title: 'Введение в информатику',
          description: 'Уроки по предмету "Информатика" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Physics: Subject = {
  id: 'physics',
  title: 'Физика',
  icon: '⚛️',
  color: '#6366F1',
  topics: [
    {
      topic: 'Основы физики',
      lessons: [
        {
          title: 'Введение в физику',
          description: 'Уроки по предмету "Физика" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Chemistry: Subject = {
  id: 'chemistry',
  title: 'Химия',
  icon: '🧪',
  color: '#84CC16',
  topics: [
    {
      topic: 'Основы химии',
      lessons: [
        {
          title: 'Введение в химию',
          description: 'Уроки по предмету "Химия" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Pe: Subject = {
  id: 'pe',
  title: 'Физкультура',
  icon: '⚽',
  color: '#14B8A6',
  topics: [
    {
      topic: 'Основы физической культуры',
      lessons: [
        {
          title: 'Введение в физкультуру',
          description: 'Уроки по предмету "Физкультура" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11SocialStudies: Subject = {
  id: 'social_studies',
  title: 'Обществознание',
  icon: '🏛️',
  color: '#7C3AED',
  topics: [
    {
      topic: 'Основы обществознания',
      lessons: [
        {
          title: 'Введение в обществознание',
          description: 'Уроки по предмету "Обществознание" для 11 класса. Скоро будет добавлено больше материалов!',
          tasks: ['Ознакомиться с предметом'],
          examples: [],
          facts: []
        }
      ]
    }
  ]
};

export const grade11Subjects = [
  grade11Russian,
  grade11Literature,
  grade11Algebra,
  grade11Geometry,
  grade11History,
  grade11Geography,
  grade11Biology,
  grade11English,
  grade11Informatics,
  grade11Physics,
  grade11Chemistry,
  grade11Pe,
  grade11SocialStudies
];
