import { Grade } from './types';
import { grade0Subjects } from './grades/grade0';
import { grade1Subjects } from './grades/grade1';
import { grade2Subjects } from './grades/grade2';
import { grade3Subjects } from './grades/grade3';
import { grade4Subjects } from './grades/grade4';
import { grade5Subjects } from './grades/grade5';
import { grade6Subjects } from './grades/grade6';
import { grade7Subjects } from './grades/grade7';
import { grade8Subjects } from './grades/grade8';
import { grade9Subjects } from './grades/grade9';
import { grade10Subjects } from './grades/grade10';
import { grade11Subjects } from './grades/grade11';

// Классы
export const GRADES: Grade[] = [
  { id: 0, title: 'Подготовительный', icon: '🎒', subjects: grade0Subjects },
  { id: 1, title: '1 класс', icon: '📚', subjects: grade1Subjects },
  { id: 2, title: '2 класс', icon: '📖', subjects: grade2Subjects },
  { id: 3, title: '3 класс', icon: '📝', subjects: grade3Subjects },
  { id: 4, title: '4 класс', icon: '✏️', subjects: grade4Subjects },
  { id: 5, title: '5 класс', icon: '🔬', subjects: grade5Subjects },
  { id: 6, title: '6 класс', icon: '🧪', subjects: grade6Subjects },
  { id: 7, title: '7 класс', icon: '📐', subjects: grade7Subjects },
  { id: 8, title: '8 класс', icon: '🎯', subjects: grade8Subjects },
  { id: 9, title: '9 класс', icon: '🏆', subjects: grade9Subjects },
  { id: 10, title: '10 класс', icon: '🎓', subjects: grade10Subjects },
  { id: 11, title: '11 класс', icon: '👑', subjects: grade11Subjects },
];

// Награды XP
export const XP_REWARDS = {
  CORRECT_ANSWER: 5,
  PERFECT_GAME: 20,
  COMPLETE_LESSON: 10,
  DAILY_LOGIN: 15,
  STREAK_BONUS: 5,
} as const;

// Звания
export const RANKS = [
  { name: 'Новичок', icon: '🌱', minLevel: 1 },
  { name: 'Ученик', icon: '📚', minLevel: 3 },
  { name: 'Знаток', icon: '⭐', minLevel: 5 },
  { name: 'Мастер', icon: '🏆', minLevel: 8 },
  { name: 'Эксперт', icon: '🎓', minLevel: 12 },
  { name: 'Гений', icon: '💎', minLevel: 16 },
  { name: 'Легенда', icon: '👑', minLevel: 20 },
];

// Достижения
export const ACHIEVEMENTS = [
  { id: 'first_lesson', name: 'Первый шаг', description: 'Завершить первый урок', icon: '👣' },
  { id: 'first_game', name: 'Игрок', description: 'Сыграть первую игру', icon: '🎮' },
  { id: 'perfect_game', name: 'Идеально!', description: 'Пройти игру без ошибок', icon: '💯' },
  { id: 'streak_3', name: 'Три дня подряд', description: 'Заниматься 3 дня подряд', icon: '🔥' },
  { id: 'streak_7', name: 'Неделя упорства', description: 'Заниматься 7 дней подряд', icon: '📅' },
  { id: 'xp_100', name: 'Сотня очков', description: 'Набрать 100 XP', icon: '💯' },
  { id: 'xp_500', name: 'Полтысячи', description: 'Набрать 500 XP', icon: '🌟' },
  { id: 'xp_1000', name: 'Тысячник', description: 'Набрать 1000 XP', icon: '🎯' },
];

// Цвета для предметов
export const SUBJECT_COLORS: { [key: string]: string } = {
  math: '#3B82F6',
  russian: '#EF4444',
  literature: '#F59E0B',
  world: '#10B981',
  english: '#8B5CF6',
  music: '#EC4899',
  art: '#F97316',
  pe: '#14B8A6',
  tech: '#6B7280',
};

// Иконки для предметов
export const SUBJECT_ICONS: { [key: string]: string } = {
  math: '🔢',
  russian: '📖',
  literature: '📚',
  world: '🌍',
  english: '🔤',
  music: '🎵',
  art: '🎨',
  pe: '⚽',
  tech: '🔧',
};

// Вычисление уровня из XP
export function calculateLevel(xp: number): number {
  return Math.floor(Math.sqrt(xp / 100)) + 1;
}

// Вычисление XP для следующего уровня
export function xpForNextLevel(level: number): number {
  return Math.pow(level, 2) * 100;
}

// Получение звания по уровню
export function getRankByLevel(level: number) {
  const sortedRanks = [...RANKS].reverse();
  for (const rank of sortedRanks) {
    if (level >= rank.minLevel) return rank;
  }
  return RANKS[0];
}
