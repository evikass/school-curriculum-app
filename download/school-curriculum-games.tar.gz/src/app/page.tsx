'use client'

import { useState } from 'react'
import { curriculum, Lesson, GradeCurriculum, LessonItem, LessonTopic } from '@/data/curriculum'
import { firstGradeGames, GameLesson } from '@/data/games'
import { prepClassGames } from '@/data/prepGames'
import { secondGradeGames } from '@/data/secondGradeGames'
import { thirdGradeGames } from '@/data/thirdGradeGames'
import { fourthGradeGames } from '@/data/fourthGradeGames'
import GamePlayer from '@/components/GamePlayer'
import {
  School,
  ChevronLeft,
  BookOpen,
  Calculator,
  Palette,
  Music,
  Dumbbell,
  Globe,
  BookOpenText,
  Languages,
  Ruler,
  Shield,
  Map,
  Leaf,
  Atom,
  FlaskConical,
  Sigma,
  Shapes,
  Landmark,
  Users,
  Monitor,
  Hammer,
  HeartHandshake,
  Telescope,
  Banknote,
  Scale,
  GraduationCap,
  MessageCircle,
  Circle,
  Pencil,
  ChevronRight,
  BookMarked,
  Gamepad2,
  Star,
  Trophy
} from 'lucide-react'

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  School,
  BookOpen,
  Calculator,
  Palette,
  Music,
  Dumbbell,
  Globe,
  BookOpenText,
  Languages,
  Ruler,
  Shield,
  Map,
  Leaf,
  Atom,
  FlaskConical,
  Sigma,
  Shapes,
  Landmark,
  Users,
  Monitor,
  Hammer,
  HeartHandshake,
  Telescope,
  Banknote,
  Scale,
  GraduationCap,
  MessageCircle,
  Circle,
  Pencil,
  BookMarked,
  Gamepad2
}

type ViewState = 'grades' | 'subjects' | 'topics' | 'lessons' | 'lesson-detail' | 'games' | 'game-list' | 'game-play'

export default function Home() {
  const [selectedGrade, setSelectedGrade] = useState<number>(1)
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null)
  const [selectedTopic, setSelectedTopic] = useState<LessonTopic | null>(null)
  const [selectedLessonItem, setSelectedLessonItem] = useState<LessonItem | null>(null)
  const [viewState, setViewState] = useState<ViewState>('grades')
  const [selectedGame, setSelectedGame] = useState<GameLesson | null>(null)
  const [earnedStars, setEarnedStars] = useState<Record<string, number>>({})

  const currentGrade: GradeCurriculum | undefined = curriculum.find(g => g.grade === selectedGrade)

  const handleGradeChange = (grade: number) => {
    setSelectedGrade(grade)
    setSelectedLesson(null)
    setSelectedTopic(null)
    setSelectedLessonItem(null)
    setSelectedGame(null)
    setViewState('subjects')
  }

  const handleLessonSelect = (lesson: Lesson) => {
    setSelectedLesson(lesson)
    setSelectedTopic(null)
    setSelectedLessonItem(null)
    if (lesson.detailedTopics && lesson.detailedTopics.length > 0) {
      setViewState('topics')
    } else {
      setViewState('lessons')
    }
  }

  const handleTopicSelect = (topic: LessonTopic) => {
    setSelectedTopic(topic)
    setSelectedLessonItem(null)
    setViewState('lessons')
  }

  const handleLessonItemClick = (item: LessonItem) => {
    setSelectedLessonItem(item)
    setViewState('lesson-detail')
  }

  const handleGameSelect = (game: GameLesson) => {
    setSelectedGame(game)
    setViewState('game-play')
  }

  const handleGameComplete = (stars: number) => {
    if (selectedGame) {
      setEarnedStars(prev => ({
        ...prev,
        [selectedGame.title]: Math.max(prev[selectedGame.title] || 0, stars)
      }))
    }
  }

  const handleBack = () => {
    switch (viewState) {
      case 'game-play':
        setViewState('game-list')
        setSelectedGame(null)
        break
      case 'game-list':
        setViewState('subjects')
        break
      case 'lesson-detail':
        setViewState('lessons')
        setSelectedLessonItem(null)
        break
      case 'lessons':
        if (selectedLesson?.detailedTopics && selectedLesson.detailedTopics.length > 0) {
          setViewState('topics')
          setSelectedTopic(null)
        } else {
          setViewState('subjects')
          setSelectedLesson(null)
        }
        break
      case 'topics':
        setViewState('subjects')
        setSelectedLesson(null)
        break
      case 'subjects':
        setViewState('grades')
        break
      default:
        break
    }
  }

  const getIconComponent = (iconName: string) => {
    return iconMap[iconName] || BookOpen
  }

  const getBackButtonText = () => {
    switch (viewState) {
      case 'game-play':
        return 'Назад к играм'
      case 'game-list':
        return 'Назад к предметам'
      case 'lesson-detail':
        return 'Назад к урокам'
      case 'lessons':
        return selectedLesson?.detailedTopics && selectedLesson.detailedTopics.length > 0 
          ? 'Назад к разделам' 
          : 'Назад к предметам'
      case 'topics':
        return 'Назад к предметам'
      case 'subjects':
        return 'Назад к выбору класса'
      default:
        return 'Назад'
    }
  }

  const getPageTitle = () => {
    switch (viewState) {
      case 'subjects':
        return currentGrade?.title || ''
      case 'topics':
        return selectedLesson?.title || ''
      case 'lessons':
        return selectedTopic?.topic || selectedLesson?.title || ''
      case 'lesson-detail':
        return selectedLessonItem?.title || ''
      case 'game-list':
        return '🎮 Мини-игры'
      case 'game-play':
        return selectedGame?.title || ''
      default:
        return ''
    }
  }

  // Get games for current grade
  const getCurrentGradeGames = () => {
    if (selectedGrade === 0) return prepClassGames
    if (selectedGrade === 1) return firstGradeGames
    if (selectedGrade === 2) return secondGradeGames
    if (selectedGrade === 3) return thirdGradeGames
    if (selectedGrade === 4) return fourthGradeGames
    return []
  }

  const currentGradeGames = getCurrentGradeGames()

  // Group games by subject
  const gamesBySubject = currentGradeGames.reduce((acc, game) => {
    if (!acc[game.subject]) {
      acc[game.subject] = []
    }
    acc[game.subject].push(game)
    return acc
  }, {} as Record<string, GameLesson[]>)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-900/70 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-center gap-3">
            <School className="w-10 h-10 text-purple-400 animate-pulse" />
            <h1 className="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">
              Полная школьная программа
            </h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Grade Selection */}
        {viewState === 'grades' && (
          <div className="animate-fadeIn">
            <h2 className="text-xl font-semibold text-white/80 mb-6 text-center">
              Выберите класс для просмотра программы
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {curriculum.map((grade) => (
                <button
                  key={grade.grade}
                  onClick={() => handleGradeChange(grade.grade)}
                  className={`
                    p-6 rounded-2xl text-lg font-medium 
                    transition-all duration-300 transform hover:scale-105
                    bg-slate-800/60 hover:bg-slate-700/60 
                    text-slate-200 hover:text-white 
                    border border-slate-700/50 hover:border-purple-500/50
                    hover:shadow-xl hover:shadow-purple-500/10
                    flex flex-col items-center gap-2
                    ${(grade.grade >= 0 && grade.grade <= 4) ? 'ring-2 ring-purple-500/50' : ''}
                  `}
                >
                  <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">
                    {grade.grade === 0 ? '🎒' : grade.grade}
                  </div>
                  <span>{grade.grade === 0 ? 'Подготов.' : `${grade.grade} класс`}</span>
                  <span className="text-xs text-slate-400">{grade.lessons.length} предм.</span>
                  {(grade.grade >= 0 && grade.grade <= 4) && (
                    <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full flex items-center gap-1">
                      <Gamepad2 className="w-3 h-3" /> Игры
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Content for other views */}
        {viewState !== 'grades' && currentGrade && (
          <div className="animate-fadeIn">
            {/* Back Button */}
            {viewState !== 'subjects' && (
              <button
                onClick={handleBack}
                className="mb-6 flex items-center gap-2 text-slate-300 hover:text-white transition-colors group"
              >
                <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                <span>{getBackButtonText()}</span>
              </button>
            )}

            {/* Page Title */}
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-300 mb-2">
                {getPageTitle()}
              </h2>
              {viewState === 'subjects' && (
                <p className="text-slate-400">
                  {currentGrade.lessons.length} предметов • Выберите предмет для просмотра
                </p>
              )}
            </div>

            {/* Subjects View */}
            {viewState === 'subjects' && (
              <>
                {/* Games Banner for classes 0-4 */}
                {(selectedGrade >= 0 && selectedGrade <= 4) && (
                  <div 
                    className="mb-8 p-6 bg-gradient-to-r from-purple-600/30 to-blue-600/30 rounded-2xl border border-purple-500/30 cursor-pointer hover:border-purple-400/50 transition-all"
                    onClick={() => setViewState('game-list')}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-purple-500/20 rounded-xl">
                          <Gamepad2 className="w-10 h-10 text-purple-400" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-white flex items-center gap-2">
                            🎮 Мини-игры для {selectedGrade === 0 ? 'подготовительного класса' : `${selectedGrade} класса`}
                            <span className="text-sm bg-yellow-500/20 text-yellow-300 px-2 py-1 rounded-full">
                              {currentGradeGames.length} игр
                            </span>
                          </h3>
                          <p className="text-purple-300">
                            Учись играючи! Пройди увлекательные мини-игры по каждому предмету
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="w-8 h-8 text-purple-400" />
                    </div>
                  </div>
                )}

                {/* Back to grades button */}
                <button
                  onClick={handleBack}
                  className="mb-6 flex items-center gap-2 text-slate-300 hover:text-white transition-colors group"
                >
                  <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                  <span>{getBackButtonText()}</span>
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-6">
                  {currentGrade.lessons.map((lesson, index) => {
                    const IconComponent = getIconComponent(lesson.icon)
                    const hasDetailed = lesson.detailedTopics && lesson.detailedTopics.length > 0
                    const hasGames = (selectedGrade >= 0 && selectedGrade <= 4) && gamesBySubject[lesson.title]
                    return (
                      <div
                        key={index}
                        className="group relative p-5 md:p-6 bg-slate-800/60 backdrop-blur-lg rounded-xl border border-slate-700/50 
                          hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10
                          hover:-translate-y-1 cursor-pointer"
                        onClick={() => handleLessonSelect(lesson)}
                      >
                        <div className="flex items-center gap-3 mb-4">
                          <div className={`p-2.5 rounded-lg bg-slate-700/50 ${lesson.color}`}>
                            <IconComponent className="w-6 h-6" />
                          </div>
                          <h3 className="text-lg font-semibold text-slate-100 group-hover:text-white transition-colors">
                            {lesson.title}
                          </h3>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-400">
                            {hasDetailed 
                              ? `${lesson.detailedTopics?.length || 0} разделов` 
                              : `${lesson.topics.length} тем`}
                          </span>
                          <span className="text-purple-400 text-sm font-medium group-hover:translate-x-1 transition-transform">
                            Открыть →
                          </span>
                        </div>

                        {hasDetailed && (
                          <div className="absolute top-2 right-2">
                            <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">
                              Подробно
                            </span>
                          </div>
                        )}

                        {hasGames && (
                          <div className="absolute bottom-2 right-2">
                            <span className="text-xs bg-green-500/20 text-green-300 px-2 py-1 rounded-full flex items-center gap-1">
                              <Gamepad2 className="w-3 h-3" />
                              {gamesBySubject[lesson.title].length} игр
                            </span>
                          </div>
                        )}

                        {/* Hover gradient overlay */}
                        <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-purple-600/5 to-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
                      </div>
                    )
                  })}
                </div>
              </>
            )}

            {/* Games List View */}
            {viewState === 'game-list' && (
              <div className="space-y-8">
                {/* Back button */}
                <button
                  onClick={handleBack}
                  className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors group"
                >
                  <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                  <span>Назад к предметам</span>
                </button>

                {Object.entries(gamesBySubject).map(([subject, games]) => {
                  const IconComponent = getIconComponent(games[0].icon)
                  return (
                    <div key={subject} className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg bg-slate-700/50 ${games[0].color}`}>
                          <IconComponent className="w-5 h-5" />
                        </div>
                        <h3 className="text-xl font-bold text-white">{subject}</h3>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {games.map((game, index) => {
                          const stars = earnedStars[game.title] || 0
                          return (
                            <div
                              key={index}
                              onClick={() => handleGameSelect(game)}
                              className="group p-4 bg-slate-800/60 backdrop-blur-lg rounded-xl border border-slate-700/50 
                                hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl
                                cursor-pointer"
                            >
                              <div className="flex items-start justify-between mb-3">
                                <h4 className="text-lg font-semibold text-slate-100 group-hover:text-white">
                                  {game.title}
                                </h4>
                                {stars > 0 && (
                                  <div className="flex gap-0.5">
                                    {[1, 2, 3].map((s) => (
                                      <Star
                                        key={s}
                                        className={`w-4 h-4 ${
                                          s <= stars 
                                            ? 'text-yellow-400 fill-yellow-400' 
                                            : 'text-slate-600'
                                        }`}
                                      />
                                    ))}
                                  </div>
                                )}
                              </div>
                              
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-slate-400">
                                  {game.tasks.length} заданий
                                </span>
                                <span className="text-sm text-purple-400 group-hover:translate-x-1 transition-transform">
                                  Играть →
                                </span>
                              </div>
                              
                              {stars === 0 && (
                                <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                                  <Trophy className="w-4 h-4" />
                                  <span>Пройди игру и заработай звёзды!</span>
                                </div>
                              )}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}

            {/* Game Play View */}
            {viewState === 'game-play' && selectedGame && (
              <GamePlayer
                game={selectedGame}
                onBack={() => {
                  setViewState('game-list')
                  setSelectedGame(null)
                }}
                onComplete={handleGameComplete}
              />
            )}

            {/* Topics View */}
            {viewState === 'topics' && selectedLesson?.detailedTopics && (
              <div className="space-y-4">
                {selectedLesson.detailedTopics.map((topic, index) => (
                  <div
                    key={index}
                    className="group p-5 bg-slate-800/60 backdrop-blur-lg rounded-xl border border-slate-700/50 
                      hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl
                      cursor-pointer"
                    onClick={() => handleTopicSelect(topic)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-blue-500 flex items-center justify-center text-white font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-slate-100 group-hover:text-white">
                            {topic.topic}
                          </h3>
                          <p className="text-sm text-slate-400">
                            {topic.lessons.length} уроков
                          </p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-purple-400 group-hover:translate-x-1 transition-all" />
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Lessons View */}
            {viewState === 'lessons' && (
              <div className="space-y-3">
                {selectedTopic ? (
                  selectedTopic.lessons.map((lessonItem, index) => (
                    <div
                      key={index}
                      className="group p-5 bg-slate-800/60 backdrop-blur-lg rounded-xl border border-slate-700/50 
                        hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl
                        cursor-pointer"
                      onClick={() => handleLessonItemClick(lessonItem)}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-r from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                            {index + 1}
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-slate-100 group-hover:text-white mb-1">
                              {lessonItem.title}
                            </h3>
                            <p className="text-sm text-slate-400 mb-2">
                              {lessonItem.description}
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {lessonItem.tasks.slice(0, 2).map((task, taskIndex) => (
                                <span key={taskIndex} className="text-xs bg-slate-700/50 text-slate-300 px-2 py-1 rounded">
                                  {task}
                                </span>
                              ))}
                              {lessonItem.tasks.length > 2 && (
                                <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded">
                                  +{lessonItem.tasks.length - 2} ещё
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-purple-400 group-hover:translate-x-1 transition-all flex-shrink-0 mt-1" />
                      </div>
                    </div>
                  ))
                ) : (
                  selectedLesson?.topics.map((topic, index) => (
                    <div
                      key={index}
                      className="p-4 bg-slate-800/60 backdrop-blur-lg rounded-xl border border-slate-700/50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-600 to-blue-500 flex items-center justify-center text-white text-sm font-bold">
                          {index + 1}
                        </div>
                        <span className="text-slate-200">{topic}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* Lesson Detail View */}
            {viewState === 'lesson-detail' && selectedLessonItem && (
              <div className="bg-slate-800/60 backdrop-blur-xl rounded-2xl p-6 md:p-8 border border-slate-700/50 shadow-xl">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`p-4 rounded-xl bg-gradient-to-br from-slate-700 to-slate-800 ${selectedLesson?.color} shadow-lg`}>
                    {(() => {
                      const IconComponent = getIconComponent(selectedLesson?.icon || 'BookOpen')
                      return <IconComponent className="w-8 h-8" />
                    })()}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-white">
                      {selectedLessonItem.title}
                    </h3>
                    <p className="text-slate-400 text-sm">
                      {selectedLesson?.title} • {selectedTopic?.topic}
                    </p>
                  </div>
                </div>

                <div className="mb-6 p-4 bg-slate-700/30 rounded-xl">
                  <h4 className="text-lg font-semibold text-slate-300 mb-2">
                    Цель урока
                  </h4>
                  <p className="text-slate-200">{selectedLessonItem.description}</p>
                </div>

                <div className="border-t border-slate-700/50 pt-6">
                  <h4 className="text-lg font-semibold text-slate-300 mb-4 flex items-center gap-2">
                    <BookMarked className="w-5 h-5" />
                    Задания урока:
                  </h4>
                  <ul className="space-y-3">
                    {selectedLessonItem.tasks.map((task, index) => (
                      <li
                        key={index}
                        className="flex items-start gap-3 p-4 rounded-lg bg-slate-700/30 hover:bg-slate-700/50 transition-colors"
                      >
                        <span className={`
                          flex-shrink-0 w-7 h-7 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 
                          flex items-center justify-center text-white text-sm font-medium
                        `}>
                          {index + 1}
                        </span>
                        <span className="text-slate-200 leading-relaxed">{task}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-white/10 py-8 text-center text-slate-400 text-sm">
        <p>
          Полная школьная программа • Классы 0-11 • Все предметы с подробными уроками и мини-играми
        </p>
      </footer>
    </div>
  )
}
