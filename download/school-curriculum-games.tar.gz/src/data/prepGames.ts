import { GameLesson } from './games'

// Мини-игры для подготовительного класса (0 класс)
export const prepClassGames: GameLesson[] = [
  // ========== ПОДГОТОВКА К ПИСЬМУ ==========
  {
    title: "Линии и фигуры",
    subject: "Подготовка к письму",
    icon: "Pencil",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какая линия прямая? ➖〰️",
        options: ["Первая", "Вторая", "Обе"],
        correctAnswer: "Первая",
        hint: "Прямая линия не изгибается"
      },
      {
        type: 'quiz',
        question: "Сколько углов у квадрата? ⬜",
        options: ["3", "4", "5"],
        correctAnswer: "4",
        hint: "Посчитай уголки у квадрата"
      },
      {
        type: 'find',
        question: "Выбери фигуры с углами:",
        options: ["Круг ⭕", "Квадрат ⬜", "Овал ⬭", "Треугольник 🔺"],
        correctAnswer: ["Квадрат ⬜", "Треугольник 🔺"],
        hint: "Углы есть у фигур с прямыми сторонами"
      },
      {
        type: 'quiz',
        question: "Какая фигура похожа на мяч?",
        options: ["Квадрат", "Круг", "Треугольник"],
        correctAnswer: "Круг",
        hint: "Мяч круглый!"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь фигуры и линии! ✏️"
    }
  },
  {
    title: "Узоры по клеточкам",
    subject: "Подготовка к письму",
    icon: "Pencil",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Продолжи узор: ⬜⬛⬜⬛... Какая следующая клетка?",
        options: ["⬜ Белая", "⬛ Чёрная"],
        correctAnswer: "⬜ Белая",
        hint: "Клетки чередуются: белая, чёрная, белая..."
      },
      {
        type: 'order',
        question: "Расставь по порядку: 2, 1, 3",
        correctAnswer: "1, 2, 3",
        hint: "От меньшего к большему"
      },
      {
        type: 'quiz',
        question: "Сколько клеточек в ряду: □□□□□?",
        options: ["3", "4", "5"],
        correctAnswer: "5",
        hint: "Посчитай каждую клеточку"
      },
      {
        type: 'find',
        question: "Какие линии можно нарисовать по линейке?",
        options: ["Прямые", "Волнистые", "Ломаные"],
        correctAnswer: ["Прямые"],
        hint: "Линейка помогает рисовать ровные линии"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты умеешь работать с узорами! 🎨"
    }
  },
  {
    title: "Направления",
    subject: "Подготовка к письму",
    icon: "Pencil",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "В какую сторону стрелка? ➡️",
        options: ["Влево", "Вправо", "Вверх"],
        correctAnswer: "Вправо",
        hint: "Куда показывает стрелка?"
      },
      {
        type: 'quiz',
        question: "Где верх? ⬆️",
        options: ["Там где стрелка", "Внизу", "Сбоку"],
        correctAnswer: "Там где стрелка",
        hint: "Стрелка показывает вверх"
      },
      {
        type: 'quiz',
        question: "В какую сторону пишем букву О? (по часовой стрелке)",
        options: ["Влево ↺", "Вправо ↻"],
        correctAnswer: "Вправо ↻",
        hint: "Как стрелки на часах"
      },
      {
        type: 'find',
        question: "Выбери направления вверх:",
        options: ["⬆️", "⬇️", "➡️", "⬅️"],
        correctAnswer: ["⬆️"],
        hint: "Стрелка вверх показывает наверх"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты понимаешь направления! 🧭"
    }
  },

  // ========== ОСНОВЫ СЧЁТА ==========
  {
    title: "Счёт до 5",
    subject: "Основы счёта",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько яблок? 🍎🍎🍎",
        options: ["2", "3", "4"],
        correctAnswer: "3",
        hint: "Посчитай: раз, два, три!"
      },
      {
        type: 'quiz',
        question: "Сколько шариков? 🎈🎈",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Посчитай внимательно"
      },
      {
        type: 'order',
        question: "Расставь по порядку: 3, 1, 2, 4",
        correctAnswer: "1, 2, 3, 4",
        hint: "Начни с самого маленького"
      },
      {
        type: 'quiz',
        question: "Какое число идёт после 4?",
        options: ["3", "5", "6"],
        correctAnswer: "5",
        hint: "Посчитай: 1, 2, 3, 4, ..."
      }
    ],
    reward: {
      stars: 3,
      message: "Умница! Ты умеешь считать до 5! 🔢"
    }
  },
  {
    title: "Счёт до 10",
    subject: "Основы счёта",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько пальцев на двух руках?",
        options: ["5", "8", "10"],
        correctAnswer: "10",
        hint: "Посчитай: 5 на одной и 5 на другой"
      },
      {
        type: 'quiz',
        question: "Какое число идёт после 7?",
        options: ["6", "8", "9"],
        correctAnswer: "8",
        hint: "Посчитай: 1, 2, 3, 4, 5, 6, 7, ..."
      },
      {
        type: 'order',
        question: "Расставь по порядку: 6, 4, 5",
        correctAnswer: "4, 5, 6",
        hint: "От меньшего к большему"
      },
      {
        type: 'fill',
        question: "Какое число между 4 и 6?",
        correctAnswer: "5",
        hint: "Посчитай: 4, ?, 6"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты умеешь считать до 10! 🎉"
    }
  },
  {
    title: "Цифры 1-5",
    subject: "Основы счёта",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Как выглядит цифра 3?",
        options: ["1", "3", "5"],
        correctAnswer: "3",
        hint: "Цифра 3 похожа на ушки зайчика"
      },
      {
        type: 'find',
        question: "Выбери цифры от 1 до 3:",
        options: ["1", "4", "2", "5", "3"],
        correctAnswer: ["1", "2", "3"],
        hint: "1, 2, 3 - первые три цифры"
      },
      {
        type: 'quiz',
        question: "Сколько это: 2?",
        options: ["Один", "Два", "Три"],
        correctAnswer: "Два",
        hint: "2 = два"
      },
      {
        type: 'match',
        question: "Соедини цифру и количество: 3 - это...",
        options: ["⭐⭐", "⭐⭐⭐", "⭐⭐⭐⭐"],
        correctAnswer: "⭐⭐⭐",
        hint: "Посчитай звёздочки"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь цифры 1-5! ✨"
    }
  },
  {
    title: "Сравнение чисел",
    subject: "Основы счёта",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что больше: 3 или 5?",
        options: ["3", "5", "Они равны"],
        correctAnswer: "5",
        hint: "5 идёт позже при счёте"
      },
      {
        type: 'quiz',
        question: "Что меньше: 2 или 4?",
        options: ["2", "4", "Они равны"],
        correctAnswer: "2",
        hint: "2 идёт раньше при счёте"
      },
      {
        type: 'quiz',
        question: "Какой знак: 3 __ 3?",
        options: ["Больше >", "Меньше <", "Равно ="],
        correctAnswer: "Равно =",
        hint: "Числа одинаковые"
      },
      {
        type: 'find',
        question: "Выбери верные неравенства:",
        options: ["5 > 3", "2 > 4", "4 = 4", "1 < 3"],
        correctAnswer: ["5 > 3", "4 = 4", "1 < 3"],
        hint: "Проверь каждое сравнение"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты умеешь сравнивать числа! ⚖️"
    }
  },

  // ========== РАЗВИТИЕ РЕЧИ ==========
  {
    title: "Звуки речи",
    subject: "Развитие речи",
    icon: "MessageCircle",
    color: "text-teal-400",
    tasks: [
      {
        type: 'quiz',
        question: "С какого звука начинается слово МАМА?",
        options: ["А", "М", "О"],
        correctAnswer: "М",
        hint: "Произнеси слово: [М]ама"
      },
      {
        type: 'find',
        question: "Выбери слова, которые начинаются на А:",
        options: ["Арбуз", "Мак", "Аист", "Сок", "Аня"],
        correctAnswer: ["Арбуз", "Аист", "Аня"],
        hint: "Прислушайся к первому звуку"
      },
      {
        type: 'quiz',
        question: "Сколько звуков в слове ДОМ?",
        options: ["2", "3", "4"],
        correctAnswer: "3",
        hint: "Д-О-М - три звука"
      },
      {
        type: 'quiz',
        question: "Какой звук последний в слове КОТ?",
        options: ["К", "О", "Т"],
        correctAnswer: "Т",
        hint: "Ко-[Т] - последний звук"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты понимаешь звуки речи! 🔊"
    }
  },
  {
    title: "Слова и слоги",
    subject: "Развитие речи",
    icon: "MessageCircle",
    color: "text-teal-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько слогов в слове МА-МА?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Хлопни: МА-МА (два хлопка)"
      },
      {
        type: 'quiz',
        question: "Сколько слогов в слове ШАР?",
        options: ["1", "2", "3"],
        correctAnswer: "1",
        hint: "Хлопни один раз: ШАР"
      },
      {
        type: 'find',
        question: "Выбери слова из 2 слогов:",
        options: ["Дом", "Вода", "Кот", "Рука", "Машина"],
        correctAnswer: ["Вода", "Рука"],
        hint: "Хлопни и посчитай"
      },
      {
        type: 'order',
        question: "Составь слово: ША, КА",
        correctAnswer: "КА, ША",
        hint: "КА-ША - какое слово?"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты понимаешь слоги! 📝"
    }
  },
  {
    title: "Предложение",
    subject: "Развитие речи",
    icon: "MessageCircle",
    color: "text-teal-400",
    tasks: [
      {
        type: 'quiz',
        question: "С чего начинается предложение?",
        options: ["С маленькой буквы", "С большой буквы", "С точки"],
        correctAnswer: "С большой буквы",
        hint: "Первое слово пишется с большой буквы"
      },
      {
        type: 'quiz',
        question: "Чем заканчивается предложение?",
        options: ["Запятой", "Точкой", "Пробелом"],
        correctAnswer: "Точкой",
        hint: "В конце предложения ставится точка"
      },
      {
        type: 'find',
        question: "Выбери правильные предложения:",
        options: ["мама дома.", "Мама дома.", "Мама дома", "Мама дома."],
        correctAnswer: ["Мама дома."],
        hint: "Начало с большой буквы, конец с точкой"
      },
      {
        type: 'quiz',
        question: "Сколько слов в предложении: «Я иду»?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Я-иду - два слова"
      }
    ],
    reward: {
      stars: 3,
      message: "Замечательно! Ты знаешь правила предложения! 📖"
    }
  },

  // ========== ОКРУЖАЮЩИЙ МИР ==========
  {
    title: "Времена года",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какое время года, когда падают листья?",
        options: ["Весна", "Лето", "Осень", "Зима"],
        correctAnswer: "Осень",
        hint: "Листья желтеют и падают осенью"
      },
      {
        type: 'quiz',
        question: "Когда можно купаться в речке?",
        options: ["Зимой", "Весной", "Летом"],
        correctAnswer: "Летом",
        hint: "Летом тепло и солнечно"
      },
      {
        type: 'find',
        question: "Что бывает зимой?",
        options: ["Снег", "Листопад", "Мороз", "Цветение", "Санки"],
        correctAnswer: ["Снег", "Мороз", "Санки"],
        hint: "Зимой холодно и снег"
      },
      {
        type: 'order',
        question: "Расставь по порядку: Лето, Зима, Осень, Весна",
        correctAnswer: "Зима, Весна, Лето, Осень",
        hint: "Начни с зимы"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь времена года! 🍂"
    }
  },
  {
    title: "Домашние животные",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Кто живёт дома с человеком?",
        options: ["Волк", "Корова", "Лиса", "Кошка", "Медведь", "Собака"],
        correctAnswer: ["Корова", "Кошка", "Собака"],
        hint: "Домашние животные живут с людьми"
      },
      {
        type: 'quiz',
        question: "Кто даёт нам молоко?",
        options: ["Кошка", "Собака", "Корова"],
        correctAnswer: "Корова",
        hint: "Большое животное с рогами"
      },
      {
        type: 'quiz',
        question: "Кто охраняет дом?",
        options: ["Кошка", "Собака", "Корова"],
        correctAnswer: "Собака",
        hint: "Это верный друг человека"
      },
      {
        type: 'quiz',
        question: "Кто ловит мышей?",
        options: ["Собака", "Корова", "Кошка"],
        correctAnswer: "Кошка",
        hint: "Это пушистое и мяукает"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь домашних животных! 🐄"
    }
  },
  {
    title: "Дикие животные",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Кто живёт в лесу?",
        options: ["Медведь", "Корова", "Заяц", "Кошка", "Лиса", "Волк"],
        correctAnswer: ["Медведь", "Заяц", "Лиса", "Волк"],
        hint: "Дикие животные живут в лесу"
      },
      {
        type: 'quiz',
        question: "Кто спит в берлоге зимой?",
        options: ["Заяц", "Медведь", "Лиса"],
        correctAnswer: "Медведь",
        hint: "Большой бурый зверь"
      },
      {
        type: 'quiz',
        question: "У кого длинные уши?",
        options: ["Медведь", "Заяц", "Волк"],
        correctAnswer: "Заяц",
        hint: "Этот зверёк прыгает"
      },
      {
        type: 'quiz',
        question: "Кто самый хищный в лесу?",
        options: ["Заяц", "Медведь", "Волк"],
        correctAnswer: "Волк",
        hint: "Серый и страшный хищник"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты знаешь лесных жителей! 🐻"
    }
  },
  {
    title: "Части суток",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Когда мы завтракаем?",
        options: ["Утром", "Днём", "Вечером"],
        correctAnswer: "Утром",
        hint: "Завтрак - утренний приём пищи"
      },
      {
        type: 'quiz',
        question: "Когда темно и мы спим?",
        options: ["Днём", "Вечером", "Ночью"],
        correctAnswer: "Ночью",
        hint: "Ночью все спят"
      },
      {
        type: 'order',
        question: "Расставь по порядку: Вечер, Утро, Ночь, День",
        correctAnswer: "Утро, День, Вечер, Ночь",
        hint: "Начни с утра"
      },
      {
        type: 'find',
        question: "Что мы делаем утром?",
        options: ["Спим", "Просыпаемся", "Завтракаем", "Смотрим звёзды", "Идём в сад"],
        correctAnswer: ["Просыпаемся", "Завтракаем", "Идём в сад"],
        hint: "Утром мы начинаем день"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь части суток! 🌅"
    }
  },

  // ========== РИСОВАНИЕ ==========
  {
    title: "Цвета радуги",
    subject: "Рисование",
    icon: "Palette",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какого цвета солнце?",
        options: ["Синее", "Жёлтое", "Зелёное"],
        correctAnswer: "Жёлтое",
        hint: "Солнце светит жёлтым светом"
      },
      {
        type: 'quiz',
        question: "Какого цвета трава?",
        options: ["Красная", "Синяя", "Зелёная"],
        correctAnswer: "Зелёная",
        hint: "Трава зелёная"
      },
      {
        type: 'find',
        question: "Выбери тёплые цвета:",
        options: ["Красный", "Синий", "Оранжевый", "Зелёный", "Жёлтый"],
        correctAnswer: ["Красный", "Оранжевый", "Жёлтый"],
        hint: "Тёплые цвета как огонь и солнце"
      },
      {
        type: 'quiz',
        question: "Какого цвета небо?",
        options: ["Зелёное", "Голубое", "Красное"],
        correctAnswer: "Голубое",
        hint: "Небо голубое в ясный день"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь цвета! 🌈"
    }
  },
  {
    title: "Формы предметов",
    subject: "Рисование",
    icon: "Palette",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "На какую фигуру похожа тарелка?",
        options: ["Квадрат", "Круг", "Треугольник"],
        correctAnswer: "Круг",
        hint: "Тарелка круглая"
      },
      {
        type: 'quiz',
        question: "На какую фигуру похожа крыша дома?",
        options: ["Круг", "Квадрат", "Треугольник"],
        correctAnswer: "Треугольник",
        hint: "Крыша похожа на треугольник"
      },
      {
        type: 'find',
        question: "Что похоже на круг?",
        options: ["Мяч", "Книга", "Колесо", "Окно", "Солнце"],
        correctAnswer: ["Мяч", "Колесо", "Солнце"],
        hint: "Круглые предметы можно катить"
      },
      {
        type: 'quiz',
        question: "На какую фигуру похож окно?",
        options: ["Круг", "Квадрат", "Треугольник"],
        correctAnswer: "Квадрат",
        hint: "Окно прямоугольное или квадратное"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты видишь формы в предметах! 🎨"
    }
  },

  // ========== ЛЕПКА ==========
  {
    title: "Формы из пластилина",
    subject: "Лепка",
    icon: "Circle",
    color: "text-amber-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какую форму легче всего слепить?",
        options: ["Шар", "Квадрат", "Пирамида"],
        correctAnswer: "Шар",
        hint: "Шар лепится круговыми движениями"
      },
      {
        type: 'quiz',
        question: "Какой формы морковка?",
        options: ["Шар", "Конус", "Куб"],
        correctAnswer: "Конус",
        hint: "Морковка сужается к низу"
      },
      {
        type: 'find',
        question: "Что можно слепить в форме шара?",
        options: ["Яблоко", "Стол", "Мяч", "Снеговик", "Дом"],
        correctAnswer: ["Яблоко", "Мяч", "Снеговик"],
        hint: "Шар - круглая форма"
      },
      {
        type: 'quiz',
        question: "Какой формы колобок?",
        options: ["Квадрат", "Шар", "Треугольник"],
        correctAnswer: "Шар",
        hint: "Колобок круглый!"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь формы для лепки! 🧸"
    }
  },

  // ========== МУЗЫКА ==========
  {
    title: "Звуки музыки",
    subject: "Музыка",
    icon: "Music",
    color: "text-cyan-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какой инструмент самый громкий?",
        options: ["Барабан", "Скрипка", "Флейта"],
        correctAnswer: "Барабан",
        hint: "По барабану стучат палочками"
      },
      {
        type: 'find',
        question: "Выбери музыкальные инструменты:",
        options: ["Пианино", "Стол", "Гитара", "Книга", "Барабан"],
        correctAnswer: ["Пианино", "Гитара", "Барабан"],
        hint: "На инструментах играют музыку"
      },
      {
        type: 'quiz',
        question: "Какой инструмент маленький и звенит?",
        options: ["Барабан", "Колокольчик", "Рояль"],
        correctAnswer: "Колокольчик",
        hint: "Динь-динь-динь!"
      },
      {
        type: 'quiz',
        question: "Как называют человека, который поёт?",
        options: ["Танцор", "Певец", "Художник"],
        correctAnswer: "Певец",
        hint: "Певец поёт песни"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь музыку! 🎵"
    }
  },

  // ========== ФИЗКУЛЬТУРА ==========
  {
    title: "Спорт и движение",
    subject: "Физкультура",
    icon: "Dumbbell",
    color: "text-orange-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какое упражнение делают лёжа?",
        options: ["Бег", "Приседания", "Отжимания"],
        correctAnswer: "Отжимания",
        hint: "Отжимания делают на полу"
      },
      {
        type: 'find',
        question: "Выбери подвижные игры:",
        options: ["Прятки", "Шахматы", "Догонялки", "Пазлы", "Прыгалки"],
        correctAnswer: ["Прятки", "Догонялки", "Прыгалки"],
        hint: "Подвижные игры требуют движения"
      },
      {
        type: 'quiz',
        question: "Что нужно делать утром?",
        options: ["Спать", "Зарядку", "Ужинать"],
        correctAnswer: "Зарядку",
        hint: "Утренняя зарядка бодрит"
      },
      {
        type: 'quiz',
        question: "Какой вид спорта зимой на снегу?",
        options: ["Плавание", "Лыжи", "Футбол"],
        correctAnswer: "Лыжи",
        hint: "Лыжи - зимний вид спорта"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты любишь спорт! 🏃"
    }
  }
]

export const getPrepGamesBySubject = (subject: string): GameLesson[] => {
  return prepClassGames.filter(game => game.subject === subject);
}

export const getPrepGameByTitle = (title: string): GameLesson | undefined => {
  return prepClassGames.find(game => game.title === title);
}
