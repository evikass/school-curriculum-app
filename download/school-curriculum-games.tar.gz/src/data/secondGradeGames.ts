import { GameLesson } from './games'

// Мини-игры для 2 класса
export const secondGradeGames: GameLesson[] = [
  // ========== РУССКИЙ ЯЗЫК ==========
  {
    title: "Части речи: Существительное",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что обозначает имя существительное?",
        options: ["Действие", "Предмет", "Признак"],
        correctAnswer: "Предмет",
        hint: "Существительное отвечает на вопросы: КТО? ЧТО?"
      },
      {
        type: 'find',
        question: "Выбери имена существительные:",
        options: ["Бежать", "Стол", "Красивый", "Книга", "Весёлый", "Писать"],
        correctAnswer: ["Стол", "Книга"],
        hint: "Существительное - это предмет"
      },
      {
        type: 'quiz',
        question: "На какой вопрос отвечает слово «ученик»?",
        options: ["Что делать?", "Какой?", "Кто?"],
        correctAnswer: "Кто?",
        hint: "Ученик - это человек"
      },
      {
        type: 'find',
        question: "Выбери одушевлённые существительные:",
        options: ["Мальчик", "Стол", "Кошка", "Дерево", "Учитель", "Камень"],
        correctAnswer: ["Мальчик", "Кошка", "Учитель"],
        hint: "Одушевлённые - живые существа"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь существительные! 📚"
    }
  },
  {
    title: "Части речи: Прилагательное",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что обозначает имя прилагательное?",
        options: ["Действие", "Предмет", "Признак предмета"],
        correctAnswer: "Признак предмета",
        hint: "Прилагательное отвечает на вопрос: КАКОЙ?"
      },
      {
        type: 'find',
        question: "Выбери имена прилагательные:",
        options: ["Дом", "Большой", "Бежать", "Красный", "Стол", "Весёлый"],
        correctAnswer: ["Большой", "Красный", "Весёлый"],
        hint: "Прилагательные описывают предметы"
      },
      {
        type: 'quiz',
        question: "На какой вопрос отвечает слово «красивый»?",
        options: ["Что делать?", "Какой?", "Кто?"],
        correctAnswer: "Какой?",
        hint: "Прилагательные отвечают на вопрос КАКОЙ?"
      },
      {
        type: 'match',
        question: "Соедини прилагательное с существительным: Красный...",
        options: ["Дом", "Цветок", "Стол"],
        correctAnswer: "Цветок",
        hint: "Цветы бывают красными"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь прилагательные! 🎨"
    }
  },
  {
    title: "Части речи: Глагол",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что обозначает глагол?",
        options: ["Предмет", "Признак", "Действие предмета"],
        correctAnswer: "Действие предмета",
        hint: "Глагол отвечает на вопросы: ЧТО ДЕЛАТЬ? ЧТО СДЕЛАТЬ?"
      },
      {
        type: 'find',
        question: "Выбери глаголы:",
        options: ["Бежать", "Стол", "Прыгать", "Красивый", "Читать", "Книга"],
        correctAnswer: ["Бежать", "Прыгать", "Читать"],
        hint: "Глаголы - это действия"
      },
      {
        type: 'quiz',
        question: "На какой вопрос отвечает слово «читать»?",
        options: ["Кто?", "Какой?", "Что делать?"],
        correctAnswer: "Что делать?",
        hint: "Читать - это действие"
      },
      {
        type: 'order',
        question: "Расставь глаголы по порядку действий: Учить, Прочитать, Взять книгу",
        correctAnswer: "Взять книгу, Читать, Учить",
        hint: "Что делаем сначала?"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты знаешь глаголы! ✍️"
    }
  },
  {
    title: "Текст и предложение",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое текст?",
        options: ["Одно слово", "Несколько предложений на одну тему", "Буквы"],
        correctAnswer: "Несколько предложений на одну тему",
        hint: "Текст состоит из предложений"
      },
      {
        type: 'find',
        question: "Выбери признаки текста:",
        options: ["Одна тема", "Наличие заголовка", "Одно слово", "Связь предложений"],
        correctAnswer: ["Одна тема", "Наличие заголовка", "Связь предложений"],
        hint: "Текст имеет тему и связные предложения"
      },
      {
        type: 'quiz',
        question: "Сколько предложений в тексте должно быть минимум?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Текст состоит минимум из 2 предложений"
      },
      {
        type: 'quiz',
        question: "Какой знак ставится в конце повествовательного предложения?",
        options: ["!", "?", "."],
        correctAnswer: ".",
        hint: "Повествовательное предложение - это утверждение"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты понимаешь текст! 📖"
    }
  },
  {
    title: "Собственные и нарицательные",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Как пишутся имена собственные?",
        options: ["С маленькой буквы", "С большой буквы", "Не важно"],
        correctAnswer: "С большой буквы",
        hint: "Имена, фамилии, названия городов пишутся с большой буквы"
      },
      {
        type: 'find',
        question: "Выбери имена собственные:",
        options: ["Москва", "город", "Маша", "девочка", "Россия", "страна"],
        correctAnswer: ["Москва", "Маша", "Россия"],
        hint: "Имена собственные - это названия"
      },
      {
        type: 'quiz',
        question: "Какое слово пишется с большой буквы?",
        options: ["собака", "Шарик", "бежать"],
        correctAnswer: "Шарик",
        hint: "Клички животных - имена собственные"
      },
      {
        type: 'fill',
        question: "Напиши первую букву слова: __оссия",
        correctAnswer: "Р",
        hint: "Название страны - имя собственное"
      }
    ],
    reward: {
      stars: 3,
      message: "Замечательно! Ты знаешь имена собственные! 🌟"
    }
  },
  {
    title: "Правописание приставок",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Где находится приставка в слове?",
        options: ["В конце", "В начале", "В середине"],
        correctAnswer: "В начале",
        hint: "Приставка стоит перед корнем"
      },
      {
        type: 'find',
        question: "Выбери слова с приставкой:",
        options: ["Дом", "Приехать", "Стол", "Написать", "Весёлый"],
        correctAnswer: ["Приехать", "Написать"],
        hint: "Приставки: при-, на-, вы-, пере-"
      },
      {
        type: 'quiz',
        question: "Какая приставка в слове «перелететь»?",
        options: ["пере-", "лете-", "ть"],
        correctAnswer: "пере-",
        hint: "Приставка в начале слова"
      },
      {
        type: 'fill',
        question: "Вставь приставку: __ходить (идти к дому)",
        correctAnswer: "при",
        hint: "Приходить = при + ходить"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь приставки! ✏️"
    }
  },

  // ========== МАТЕМАТИКА ==========
  {
    title: "Числа от 1 до 100",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько десятков в числе 45?",
        options: ["4", "5", "45"],
        correctAnswer: "4",
        hint: "45 = 4 десятка + 5 единиц"
      },
      {
        type: 'quiz',
        question: "Какое число состоит из 3 десятков и 7 единиц?",
        options: ["73", "37", "10"],
        correctAnswer: "37",
        hint: "3 десятка = 30, плюс 7 = 37"
      },
      {
        type: 'order',
        question: "Расставь по возрастанию: 45, 23, 67, 12",
        correctAnswer: "12, 23, 45, 67",
        hint: "От меньшего к большему"
      },
      {
        type: 'fill',
        question: "Какое число идёт после 39?",
        correctAnswer: "40",
        hint: "39 + 1 = ?"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь числа до 100! 🔢"
    }
  },
  {
    title: "Сложение до 100",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "25 + 13 = ?",
        options: ["38", "35", "42"],
        correctAnswer: "38",
        hint: "25 + 10 = 35, 35 + 3 = 38"
      },
      {
        type: 'quiz',
        question: "34 + 28 = ?",
        options: ["52", "62", "72"],
        correctAnswer: "62",
        hint: "34 + 28 = 30 + 20 + 4 + 8 = 62"
      },
      {
        type: 'fill',
        question: "47 + __ = 75",
        correctAnswer: "28",
        hint: "75 - 47 = ?"
      },
      {
        type: 'find',
        question: "Выбери верные равенства:",
        options: ["45+23=68", "34+18=52", "56+14=60", "27+33=60"],
        correctAnswer: ["45+23=68", "27+33=60"],
        hint: "Проверь каждое равенство"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты умеешь складывать! ➕"
    }
  },
  {
    title: "Вычитание до 100",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "56 - 23 = ?",
        options: ["33", "43", "23"],
        correctAnswer: "33",
        hint: "56 - 20 = 36, 36 - 3 = 33"
      },
      {
        type: 'quiz',
        question: "80 - 35 = ?",
        options: ["35", "45", "55"],
        correctAnswer: "45",
        hint: "80 - 30 = 50, 50 - 5 = 45"
      },
      {
        type: 'fill',
        question: "64 - __ = 28",
        correctAnswer: "36",
        hint: "64 - 28 = ?"
      },
      {
        type: 'quiz',
        question: "В классе 28 учеников. 12 ушли домой. Сколько осталось?",
        options: ["14", "16", "18"],
        correctAnswer: "16",
        hint: "28 - 12 = ?"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты умеешь вычитать! ➖"
    }
  },
  {
    title: "Умножение: основы",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое умножение?",
        options: ["Сложение одинаковых чисел", "Вычитание", "Деление"],
        correctAnswer: "Сложение одинаковых чисел",
        hint: "2 × 3 = 2 + 2 + 2"
      },
      {
        type: 'quiz',
        question: "2 × 3 = ?",
        options: ["5", "6", "8"],
        correctAnswer: "6",
        hint: "2 + 2 + 2 = 6"
      },
      {
        type: 'quiz',
        question: "5 × 2 = ?",
        options: ["7", "10", "12"],
        correctAnswer: "10",
        hint: "5 + 5 = 10"
      },
      {
        type: 'find',
        question: "Выбери верные равенства:",
        options: ["3×2=6", "4×2=6", "2×5=10", "2×7=14"],
        correctAnswer: ["3×2=6", "2×5=10", "2×7=14"],
        hint: "Проверь каждое умножение"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты понимаешь умножение! ✖️"
    }
  },
  {
    title: "Таблица умножения на 2",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "2 × 4 = ?",
        options: ["6", "8", "10"],
        correctAnswer: "8",
        hint: "2 + 2 + 2 + 2 = 8"
      },
      {
        type: 'quiz',
        question: "2 × 7 = ?",
        options: ["12", "14", "16"],
        correctAnswer: "14",
        hint: "7 × 2 = 14"
      },
      {
        type: 'fill',
        question: "2 × __ = 18",
        correctAnswer: "9",
        hint: "18 : 2 = ?"
      },
      {
        type: 'quiz',
        question: "Сколько лап у 4 кошек? (У каждой по 4 лапы)",
        options: ["8", "12", "16"],
        correctAnswer: "8",
        hint: "4 × 2 = ? (Но у кошки 4 лапы, значит 4 × 4... подожди, это не на 2! Ответ 16)"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь таблицу на 2! 🎯"
    }
  },
  {
    title: "Таблица умножения на 3",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "3 × 4 = ?",
        options: ["9", "12", "15"],
        correctAnswer: "12",
        hint: "3 + 3 + 3 + 3 = 12"
      },
      {
        type: 'quiz',
        question: "3 × 5 = ?",
        options: ["12", "15", "18"],
        correctAnswer: "15",
        hint: "3 × 5 = 15"
      },
      {
        type: 'fill',
        question: "3 × __ = 21",
        correctAnswer: "7",
        hint: "21 : 3 = ?"
      },
      {
        type: 'quiz',
        question: "3 × 9 = ?",
        options: ["24", "27", "30"],
        correctAnswer: "27",
        hint: "3 × 9 = 27"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты знаешь таблицу на 3! 🏆"
    }
  },
  {
    title: "Деление: основы",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое деление?",
        options: ["Обратное умножению", "Сложение", "Умножение"],
        correctAnswer: "Обратное умножению",
        hint: "Если 2 × 3 = 6, то 6 : 3 = 2"
      },
      {
        type: 'quiz',
        question: "12 : 3 = ?",
        options: ["3", "4", "6"],
        correctAnswer: "4",
        hint: "12 : 3 = 4 (потому что 3 × 4 = 12)"
      },
      {
        type: 'quiz',
        question: "15 : 5 = ?",
        options: ["2", "3", "5"],
        correctAnswer: "3",
        hint: "5 × 3 = 15"
      },
      {
        type: 'fill',
        question: "__ : 4 = 5",
        correctAnswer: "20",
        hint: "4 × 5 = ?"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты понимаешь деление! ➗"
    }
  },
  {
    title: "Величины: длина",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько сантиметров в 1 дециметре?",
        options: ["5 см", "10 см", "100 см"],
        correctAnswer: "10 см",
        hint: "1 дм = 10 см"
      },
      {
        type: 'quiz',
        question: "Сколько сантиметров в 1 метре?",
        options: ["10 см", "100 см", "1000 см"],
        correctAnswer: "100 см",
        hint: "1 м = 100 см"
      },
      {
        type: 'find',
        question: "Выбери единицы длины:",
        options: ["Сантиметр", "Килограмм", "Метр", "Литр", "Дециметр"],
        correctAnswer: ["Сантиметр", "Метр", "Дециметр"],
        hint: "Единицы длины измеряют расстояние"
      },
      {
        type: 'quiz',
        question: "Что больше: 1 м или 50 см?",
        options: ["1 м", "50 см", "Они равны"],
        correctAnswer: "1 м",
        hint: "1 м = 100 см"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь единицы длины! 📏"
    }
  },

  // ========== ЛИТЕРАТУРНОЕ ЧТЕНИЕ ==========
  {
    title: "Басни И.А. Крылова",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое басня?",
        options: ["Сказка", "Короткий рассказ с моралью", "Стихотворение"],
        correctAnswer: "Короткий рассказ с моралью",
        hint: "Басня учит чему-то важному"
      },
      {
        type: 'quiz',
        question: "Кто написал басню «Мартышка и Очки»?",
        options: ["Пушкин", "Крылов", "Толстой"],
        correctAnswer: "Крылов",
        hint: "Иван Андреевич Крылов - великий баснописец"
      },
      {
        type: 'find',
        question: "Выбери басни Крылова:",
        options: ["Мартышка и Очки", "Колобок", "Ворона и Лисица", "Теремок", "Стрекоза и Муравей"],
        correctAnswer: ["Мартышка и Очки", "Ворона и Лисица", "Стрекоза и Муравей"],
        hint: "Крылов писал басни о животных"
      },
      {
        type: 'quiz',
        question: "Что такое мораль в басне?",
        options: ["Начало", "Поучительный вывод", "Конец"],
        correctAnswer: "Поучительный вывод",
        hint: "Мораль - это главный урок басни"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь басни! 📖"
    }
  },
  {
    title: "Сказки А.С. Пушкина",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Кто написал «Сказку о рыбаке и рыбке»?",
        options: ["Крылов", "Пушкин", "Толстой"],
        correctAnswer: "Пушкин",
        hint: "Александр Сергеевич Пушкин"
      },
      {
        type: 'find',
        question: "Выбери сказки Пушкина:",
        options: ["Сказка о царе Салтане", "Колобок", "Сказка о рыбаке и рыбке", "Теремок", "Сказка о золотом петушке"],
        correctAnswer: ["Сказка о царе Салтане", "Сказка о рыбаке и рыбке", "Сказка о золотом петушке"],
        hint: "Пушкин написал много сказок в стихах"
      },
      {
        type: 'quiz',
        question: "Кого старик ловил в море?",
        options: ["Акулу", "Золотую рыбку", "Кита"],
        correctAnswer: "Золотую рыбку",
        hint: "Золотая рыбка исполняла желания"
      },
      {
        type: 'quiz',
        question: "Чем закончилась сказка о рыбаке и рыбке?",
        options: ["Старуха стала царицей", "Разбитое корыто", "Золотой дворец"],
        correctAnswer: "Разбитое корыто",
        hint: "Жадность старухи привела к беде"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь сказки Пушкина! ✨"
    }
  },
  {
    title: "Рассказы Л.Н. Толстого",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Кто написал рассказы для детей?",
        options: ["Пушкин", "Толстой", "Крылов"],
        correctAnswer: "Толстой",
        hint: "Лев Николаевич Толстой"
      },
      {
        type: 'find',
        question: "Выбери произведения Толстого:",
        options: ["Акула", "Колобок", "Лев и собачка", "Теремок", "Филипок"],
        correctAnswer: ["Акула", "Лев и собачка", "Филипок"],
        hint: "Толстой писал рассказы о детях и животных"
      },
      {
        type: 'quiz',
        question: "О чём рассказ «Акула»?",
        options: ["О рыбалке", "О спасении мальчиков", "О море"],
        correctAnswer: "О спасении мальчиков",
        hint: "Отец спас сыновей от акулы"
      },
      {
        type: 'quiz',
        question: "Какие чувства учит понимать Толстой?",
        options: ["Только радость", "Доброту и смелость", "Только грусть"],
        correctAnswer: "Доброту и смелость",
        hint: "Толстой учит быть хорошим человеком"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь рассказы Толстого! 📚"
    }
  },
  {
    title: "Устное народное творчество",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое устное народное творчество?",
        options: ["Книги", "Фольклор", "Песни"],
        correctAnswer: "Фольклор",
        hint: "Произведения, созданные народом"
      },
      {
        type: 'find',
        question: "Выбери жанры устного народного творчества:",
        options: ["Сказка", "Пословица", "Рассказ", "Песня", "Загадка"],
        correctAnswer: ["Сказка", "Пословица", "Песня", "Загадка"],
        hint: "Фольклор - это народные произведения"
      },
      {
        type: 'quiz',
        question: "Что такое пословица?",
        options: ["Длинная сказка", "Краткое мудрое изречение", "Песня"],
        correctAnswer: "Краткое мудрое изречение",
        hint: "Пословица учит мудрости"
      },
      {
        type: 'quiz',
        question: "Продолжи пословицу: «Терпение и труд...»",
        options: ["всё перетрут", "всё смогут", "всё сломают"],
        correctAnswer: "всё перетрут",
        hint: "Терпение и труд всё перетрут"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь народное творчество! 🌟"
    }
  },

  // ========== ОКРУЖАЮЩИЙ МИР ==========
  {
    title: "Живая и неживая природа",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что относится к живой природе?",
        options: ["Камень", "Дерево", "Вода"],
        correctAnswer: "Дерево",
        hint: "Живая природа - это растения и животные"
      },
      {
        type: 'find',
        question: "Выбери объекты живой природы:",
        options: ["Птица", "Камень", "Рыба", "Солнце", "Цветок", "Вода"],
        correctAnswer: ["Птица", "Рыба", "Цветок"],
        hint: "Живые существа дышат, растут, размножаются"
      },
      {
        type: 'find',
        question: "Выбери объекты неживой природы:",
        options: ["Камень", "Дерево", "Вода", "Воздух", "Собака", "Солнце"],
        correctAnswer: ["Камень", "Вода", "Воздух", "Солнце"],
        hint: "Неживая природа не дышит и не растёт"
      },
      {
        type: 'quiz',
        question: "Какой признак живой природы?",
        options: ["Не меняется", "Дышит и растёт", "Не двигается"],
        correctAnswer: "Дышит и растёт",
        hint: "Живые существа дышат, питаются, растут"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты различаешь природу! 🌿"
    }
  },
  {
    title: "Растения и их части",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери части растения:",
        options: ["Корень", "Голова", "Стебель", "Лист", "Ноги", "Цветок"],
        correctAnswer: ["Корень", "Стебель", "Лист", "Цветок"],
        hint: "Растение состоит из корня, стебля, листьев, цветка"
      },
      {
        type: 'quiz',
        question: "Какая часть растения впитывает воду из земли?",
        options: ["Листья", "Корень", "Цветок"],
        correctAnswer: "Корень",
        hint: "Корень находится в земле"
      },
      {
        type: 'quiz',
        question: "Какая часть растения делает питание?",
        options: ["Корень", "Стебель", "Листья"],
        correctAnswer: "Листья",
        hint: "Листья поглощают солнечный свет"
      },
      {
        type: 'quiz',
        question: "Для чего растению нужен цветок?",
        options: ["Для красоты", "Для размножения", "Для питания"],
        correctAnswer: "Для размножения",
        hint: "Из цветка образуются плоды и семена"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь строение растений! 🌸"
    }
  },
  {
    title: "Животные и их группы",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери группы животных:",
        options: ["Насекомые", "Деревья", "Птицы", "Рыбы", "Цветы", "Звери"],
        correctAnswer: ["Насекомые", "Птицы", "Рыбы", "Звери"],
        hint: "Животные делятся на группы"
      },
      {
        type: 'quiz',
        question: "К какой группе относится бабочка?",
        options: ["Птицы", "Насекомые", "Звери"],
        correctAnswer: "Насекомые",
        hint: "Бабочки - это насекомые с крыльями"
      },
      {
        type: 'quiz',
        question: "Чем покрыто тело птиц?",
        options: ["Шерсть", "Перья", "Чешуя"],
        correctAnswer: "Перья",
        hint: "Птицы покрыты перьями"
      },
      {
        type: 'quiz',
        question: "Чем покрыто тело рыб?",
        options: ["Шерсть", "Перья", "Чешуя"],
        correctAnswer: "Чешуя",
        hint: "Рыбы покрыты чешуёй"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь группы животных! 🐾"
    }
  },
  {
    title: "Экология и охрана природы",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое экология?",
        options: ["Наука о природе", "Наука о космосе", "Наука о машинах"],
        correctAnswer: "Наука о природе",
        hint: "Экология изучает связь живых существ с природой"
      },
      {
        type: 'find',
        question: "Как можно беречь природу?",
        options: ["Не мусорить", "Сажать деревья", "Ломать ветки", "Беречь воду", "Рвать цветы"],
        correctAnswer: ["Не мусорить", "Сажать деревья", "Беречь воду"],
        hint: "Природу нужно охранять"
      },
      {
        type: 'quiz',
        question: "Почему нельзя разжигать костёр в лесу?",
        options: ["Шумно", "Может быть пожар", "Холодно"],
        correctAnswer: "Может быть пожар",
        hint: "Костёр может вызвать лесной пожар"
      },
      {
        type: 'quiz',
        question: "Что такое Красная книга?",
        options: ["Книга красного цвета", "Книга редких животных", "Сказки"],
        correctAnswer: "Книга редких животных",
        hint: "В Красной книге - исчезающие виды"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты понимаешь экологию! 🌍"
    }
  },

  // ========== ИНОСТРАННЫЙ ЯЗЫК ==========
  {
    title: "My Family - Моя семья",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Mother - это?",
        options: ["Папа", "Мама", "Брат"],
        correctAnswer: "Мама",
        hint: "Mother = мама"
      },
      {
        type: 'quiz',
        question: "Как будет «папа» по-английски?",
        options: ["Mother", "Father", "Brother"],
        correctAnswer: "Father",
        hint: "Father = папа"
      },
      {
        type: 'find',
        question: "Выбери слова о семье:",
        options: ["Mother", "Cat", "Father", "Dog", "Sister", "Brother"],
        correctAnswer: ["Mother", "Father", "Sister", "Brother"],
        hint: "Family = семья"
      },
      {
        type: 'quiz',
        question: "Sister - это?",
        options: ["Брат", "Сестра", "Мама"],
        correctAnswer: "Сестра",
        hint: "Sister = сестра"
      }
    ],
    reward: {
      stars: 3,
      message: "Great! Ты знаешь семью по-английски! 👨‍👩‍👧‍👦"
    }
  },
  {
    title: "Food - Еда",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Apple - это?",
        options: ["Груша", "Яблоко", "Апельсин"],
        correctAnswer: "Яблоко",
        hint: "Apple = яблоко"
      },
      {
        type: 'quiz',
        question: "Как будет «хлеб» по-английски?",
        options: ["Bread", "Water", "Milk"],
        correctAnswer: "Bread",
        hint: "Bread = хлеб"
      },
      {
        type: 'find',
        question: "Выбери названия еды:",
        options: ["Apple", "Cat", "Bread", "Dog", "Milk", "Water"],
        correctAnswer: ["Apple", "Bread", "Milk", "Water"],
        hint: "Food = еда"
      },
      {
        type: 'quiz',
        question: "Milk - это?",
        options: ["Вода", "Сок", "Молоко"],
        correctAnswer: "Молоко",
        hint: "Milk = молоко"
      }
    ],
    reward: {
      stars: 3,
      message: "Excellent! Ты знаешь еду по-английски! 🍎"
    }
  },
  {
    title: "My House - Мой дом",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "House - это?",
        options: ["Дом", "Школа", "Магазин"],
        correctAnswer: "Дом",
        hint: "House = дом"
      },
      {
        type: 'quiz',
        question: "Как будет «комната» по-английски?",
        options: ["House", "Room", "Door"],
        correctAnswer: "Room",
        hint: "Room = комната"
      },
      {
        type: 'find',
        question: "Выбери слова о доме:",
        options: ["House", "Cat", "Room", "Dog", "Door", "Window"],
        correctAnswer: ["House", "Room", "Door", "Window"],
        hint: "House = дом, Room = комната"
      },
      {
        type: 'quiz',
        question: "Window - это?",
        options: ["Дверь", "Окно", "Стол"],
        correctAnswer: "Окно",
        hint: "Window = окно"
      }
    ],
    reward: {
      stars: 3,
      message: "Wonderful! Ты знаешь дом по-английски! 🏠"
    }
  },
  {
    title: "Weather - Погода",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Sunny - это?",
        options: ["Дождливо", "Солнечно", "Ветрено"],
        correctAnswer: "Солнечно",
        hint: "Sun = солнце, Sunny = солнечно"
      },
      {
        type: 'quiz',
        question: "Как будет «дождь» по-английски?",
        options: ["Snow", "Rain", "Wind"],
        correctAnswer: "Rain",
        hint: "Rain = дождь"
      },
      {
        type: 'find',
        question: "Выбери слова о погоде:",
        options: ["Sunny", "Cat", "Rainy", "Dog", "Windy", "Snowy"],
        correctAnswer: ["Sunny", "Rainy", "Windy", "Snowy"],
        hint: "Weather = погода"
      },
      {
        type: 'quiz',
        question: "Snow - это?",
        options: ["Дождь", "Снег", "Ветер"],
        correctAnswer: "Снег",
        hint: "Snow = снег"
      }
    ],
    reward: {
      stars: 3,
      message: "Great job! Ты знаешь погоду по-английски! ☀️"
    }
  },

  // ========== ТЕХНОЛОГИЯ ==========
  {
    title: "Работа с бумагой",
    subject: "Технология",
    icon: "Ruler",
    color: "text-yellow-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какой инструмент нужен для резки бумаги?",
        options: ["Молоток", "Ножницы", "Пила"],
        correctAnswer: "Ножницы",
        hint: "Ножницы режут бумагу"
      },
      {
        type: 'find',
        question: "Выбери материалы для аппликации:",
        options: ["Бумага", "Камень", "Клей", "Металл", "Картон", "Стекло"],
        correctAnswer: ["Бумага", "Клей", "Картон"],
        hint: "Аппликация делается из бумаги"
      },
      {
        type: 'quiz',
        question: "Что такое аппликация?",
        options: ["Рисование", "Наклеивание фигур", "Лепка"],
        correctAnswer: "Наклеивание фигур",
        hint: "Аппликация - наклеивание вырезанных фигур"
      },
      {
        type: 'quiz',
        question: "Как правильно передавать ножницы?",
        options: ["Остриём вперёд", "Колечками вперёд", "Бросить"],
        correctAnswer: "Колечками вперёд",
        hint: "Ножницы передают закрытыми, колечками вперёд"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь работу с бумагой! ✂️"
    }
  },
  {
    title: "Оригами",
    subject: "Технология",
    icon: "Ruler",
    color: "text-yellow-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое оригами?",
        options: ["Лепка из глины", "Складывание из бумаги", "Рисование"],
        correctAnswer: "Складывание из бумаги",
        hint: "Оригами - японское искусство складывания"
      },
      {
        type: 'quiz',
        question: "Какой формы нужен лист для оригами?",
        options: ["Треугольник", "Квадрат", "Круг"],
        correctAnswer: "Квадрат",
        hint: "Оригами делают из квадратного листа"
      },
      {
        type: 'find',
        question: "Что можно сделать в технике оригами?",
        options: ["Журавлик", "Лягушка", "Картина", "Кораблик", "Стул", "Самолётик"],
        correctAnswer: ["Журавлик", "Лягушка", "Кораблик", "Самолётик"],
        hint: "Оригами - это фигурки из бумаги"
      },
      {
        type: 'quiz',
        question: "Нужен ли клей для оригами?",
        options: ["Да", "Нет", "Иногда"],
        correctAnswer: "Нет",
        hint: "Оригами складывается без клея"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь оригами! 📄"
    }
  },

  // ========== ИЗОБРАЗИТЕЛЬНОЕ ИСКУССТВО ==========
  {
    title: "Цвета и оттенки",
    subject: "Изобразительное искусство",
    icon: "Palette",
    color: "text-rose-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какие цвета называют основными?",
        options: ["Красный, синий, жёлтый", "Зелёный, оранжевый, фиолетовый", "Чёрный, белый, серый"],
        correctAnswer: "Красный, синий, жёлтый",
        hint: "Основные цвета нельзя получить смешиванием"
      },
      {
        type: 'quiz',
        question: "Какой цвет получится при смешивании красного и жёлтого?",
        options: ["Зелёный", "Оранжевый", "Фиолетовый"],
        correctAnswer: "Оранжевый",
        hint: "Красный + Жёлтый = Оранжевый"
      },
      {
        type: 'quiz',
        question: "Какой цвет получится при смешивании синего и жёлтого?",
        options: ["Зелёный", "Оранжевый", "Фиолетовый"],
        correctAnswer: "Зелёный",
        hint: "Синий + Жёлтый = Зелёный"
      },
      {
        type: 'find',
        question: "Выбери тёплые цвета:",
        options: ["Красный", "Синий", "Оранжевый", "Зелёный", "Жёлтый", "Фиолетовый"],
        correctAnswer: ["Красный", "Оранжевый", "Жёлтый"],
        hint: "Тёплые цвета напоминают огонь и солнце"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь цвета! 🎨"
    }
  },
  {
    title: "Жанры живописи",
    subject: "Изобразительное искусство",
    icon: "Palette",
    color: "text-rose-400",
    tasks: [
      {
        type: 'quiz',
        question: "Что такое натюрморт?",
        options: ["Рисунок природы", "Рисунок предметов", "Рисунок человека"],
        correctAnswer: "Рисунок предметов",
        hint: "Натюрморт - изображение предметов"
      },
      {
        type: 'quiz',
        question: "Что такое пейзаж?",
        options: ["Рисунок природы", "Рисунок предметов", "Рисунок человека"],
        correctAnswer: "Рисунок природы",
        hint: "Пейзаж - изображение природы"
      },
      {
        type: 'find',
        question: "Что можно изобразить в натюрморте?",
        options: ["Фрукты", "Горы", "Цветы", "Реку", "Посуду", "Лес"],
        correctAnswer: ["Фрукты", "Цветы", "Посуду"],
        hint: "Натюрморт - это предметы"
      },
      {
        type: 'quiz',
        question: "Что изображают на портрете?",
        options: ["Природу", "Человека", "Предметы"],
        correctAnswer: "Человека",
        hint: "Портрет - изображение человека"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь жанры живописи! 🖼️"
    }
  },

  // ========== МУЗЫКА ==========
  {
    title: "Музыкальные инструменты",
    subject: "Музыка",
    icon: "Music",
    color: "text-cyan-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери музыкальные инструменты:",
        options: ["Пианино", "Стол", "Гитара", "Книга", "Скрипка", "Барабан"],
        correctAnswer: ["Пианино", "Гитара", "Скрипка", "Барабан"],
        hint: "На музыкальных инструментах играют музыку"
      },
      {
        type: 'quiz',
        question: "Какой инструмент самый большой?",
        options: ["Скрипка", "Рояль", "Флейта"],
        correctAnswer: "Рояль",
        hint: "Рояль - это большой пианино"
      },
      {
        type: 'quiz',
        question: "У какого инструмента есть струны?",
        options: ["Барабан", "Гитара", "Труба"],
        correctAnswer: "Гитара",
        hint: "На гитаре играют, дёргая струны"
      },
      {
        type: 'quiz',
        question: "Какой инструмент нужно дуть?",
        options: ["Пианино", "Гитара", "Флейта"],
        correctAnswer: "Флейта",
        hint: "Флейта - духовой инструмент"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь инструменты! 🎵"
    }
  },
  {
    title: "Музыкальные жанры",
    subject: "Музыка",
    icon: "Music",
    color: "text-cyan-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери музыкальные жанры:",
        options: ["Песня", "Танец", "Марш", "Книга", "Опера", "Сказка"],
        correctAnswer: ["Песня", "Танец", "Марш", "Опера"],
        hint: "Музыкальные жанры - виды музыки"
      },
      {
        type: 'quiz',
        question: "Какую музыку маршируют?",
        options: ["Колыбельную", "Марш", "Танец"],
        correctAnswer: "Марш",
        hint: "Марш - музыка для ходьбы строем"
      },
      {
        type: 'quiz',
        question: "Какую музыку поют?",
        options: ["Песню", "Марш", "Симфонию"],
        correctAnswer: "Песню",
        hint: "Песня - это музыка со словами"
      },
      {
        type: 'quiz',
        question: "Что такое опера?",
        options: ["Спектакль с музыкой", "Танец", "Книга"],
        correctAnswer: "Спектакль с музыкой",
        hint: "Опера - музыкальный спектакль"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь музыкальные жанры! 🎶"
    }
  },

  // ========== ФИЗИЧЕСКАЯ КУЛЬТУРА ==========
  {
    title: "Гимнастика и упражнения",
    subject: "Физическая культура",
    icon: "Dumbbell",
    color: "text-orange-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери упражнения для зарядки:",
        options: ["Наклоны", "Приседания", "Сон", "Прыжки", "Еда", "Бег на месте"],
        correctAnswer: ["Наклоны", "Приседания", "Прыжки", "Бег на месте"],
        hint: "Зарядка - это физические упражнения"
      },
      {
        type: 'quiz',
        question: "Зачем нужна разминка перед спортом?",
        options: ["Чтобы устать", "Чтобы разогреть мышцы", "Чтобы поспать"],
        correctAnswer: "Чтобы разогреть мышцы",
        hint: "Разминка готовит мышцы к нагрузке"
      },
      {
        type: 'quiz',
        question: "Сколько раз нужно присесть на уроке физкультуры?",
        options: ["Столько, сколько скажет учитель", "100 раз", "1 раз"],
        correctAnswer: "Столько, сколько скажет учитель",
        hint: "Нужно слушать учителя"
      },
      {
        type: 'quiz',
        question: "Как правильно дышать при беге?",
        options: ["Задерживать дыхание", "Равномерно носом", "Только ртом"],
        correctAnswer: "Равномерно носом",
        hint: "При беге дышат носом равномерно"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь гимнастику! 🤸"
    }
  },
  {
    title: "Подвижные игры",
    subject: "Физическая культура",
    icon: "Dumbbell",
    color: "text-orange-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери подвижные игры:",
        options: ["Прятки", "Шахматы", "Догонялки", "Пазлы", "Прыгалки", "Мяч"],
        correctAnswer: ["Прятки", "Догонялки", "Прыгалки", "Мяч"],
        hint: "Подвижные игры требуют движения"
      },
      {
        type: 'quiz',
        question: "Как играть безопасно?",
        options: ["Толкаться", "Соблюдать правила", "Кричать"],
        correctAnswer: "Соблюдать правила",
        hint: "Правила игры обеспечивают безопасность"
      },
      {
        type: 'quiz',
        question: "Что делать, если упал и больно?",
        options: ["Продолжать играть", "Сказать учителю", "Плакать тихо"],
        correctAnswer: "Сказать учителю",
        hint: "При травме нужно обратиться к учителю"
      },
      {
        type: 'quiz',
        question: "Какая обувь нужна для физкультуры?",
        options: ["Туфли", "Кроссовки", "Сапоги"],
        correctAnswer: "Кроссовки",
        hint: "Кроссовки удобны для бега и прыжков"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь правила игр! 🏃"
    }
  }
]

export const getSecondGradeGamesBySubject = (subject: string): GameLesson[] => {
  return secondGradeGames.filter(game => game.subject === subject);
}

export const getSecondGradeGameByTitle = (title: string): GameLesson | undefined => {
  return secondGradeGames.find(game => game.title === title);
}
