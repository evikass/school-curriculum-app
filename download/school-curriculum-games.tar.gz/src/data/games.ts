export interface GameTask {
  type: 'quiz' | 'match' | 'order' | 'find' | 'fill' | 'drag';
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  hint?: string;
  image?: string;
}

export interface GameLesson {
  title: string;
  subject: string;
  icon: string;
  color: string;
  tasks: GameTask[];
  reward: {
    stars: number;
    message: string;
  };
}

export const firstGradeGames: GameLesson[] = [
  // ========== РУССКИЙ ЯЗЫК ==========
  {
    title: "Знакомство с буквой А",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какой звук обозначает буква А?",
        options: ["Гласный", "Согласный"],
        correctAnswer: "Гласный",
        hint: "Этот звук произносится свободно, без преград!"
      },
      {
        type: 'find',
        question: "Найди все буквы А в словах:",
        options: ["МАМА", "ПАПА", "АННА", "ОЛЯ"],
        correctAnswer: ["МАМА", "ПАПА", "АННА"],
        hint: "Буква А есть в начале слова и в середине"
      },
      {
        type: 'match',
        question: "Соедини картинку со словом:",
        options: ["АРБУЗ", "АНАНАС", "АИСТ"],
        correctAnswer: "АРБУЗ",
        hint: "Это большой полосатый и сладкий!"
      },
      {
        type: 'quiz',
        question: "Сколько звуков [а] в слове БАНАН?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Произнеси слово медленно и послушай!"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты освоил букву А! 🌟"
    }
  },
  {
    title: "Буквы О и о",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какое слово начинается с буквы О?",
        options: ["ОЛЕНЬ", "ЕНОТ", "УТКА"],
        correctAnswer: "ОЛЕНЬ",
        hint: "Это животное с красивыми рогами"
      },
      {
        type: 'fill',
        question: "Вставь букву О: К_Т",
        correctAnswer: "О",
        hint: "Это пушистое домашнее животное"
      },
      {
        type: 'find',
        question: "Выбери слова с буквой О:",
        options: ["ДОМ", "КОТ", "ПАРК", "МОСТ", "СУП"],
        correctAnswer: ["ДОМ", "КОТ", "МОСТ"],
        hint: "Прочитай каждое слово внимательно"
      },
      {
        type: 'quiz',
        question: "Буква О обозначает:",
        options: ["Гласный звук", "Согласный звук"],
        correctAnswer: "Гласный звук",
        hint: "Её можно пропеть: О-о-о!"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты знаешь букву О! 🎉"
    }
  },
  {
    title: "ЖИ-ШИ пиши с И",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'fill',
        question: "Вставь пропущенную букву: МАШ__НА",
        correctAnswer: "И",
        hint: "Вспомни правило: ЖИ-ШИ пиши с И!"
      },
      {
        type: 'quiz',
        question: "Как правильно написать?",
        options: ["ШЫНА", "ШИНА"],
        correctAnswer: "ШИНА",
        hint: "ШИ всегда пишется с буквой И"
      },
      {
        type: 'find',
        question: "Выбери слова с орфограммой ЖИ-ШИ:",
        options: ["ЖИРАФ", "ШИЛО", "ЖИЗНЬ", "МАШИНА", "МАМА"],
        correctAnswer: ["ЖИРАФ", "ШИЛО", "ЖИЗНЬ", "МАШИНА"],
        hint: "Ищи сочетания ЖИ и ШИ"
      },
      {
        type: 'quiz',
        question: "В слове ЛЫЖИ сколько букв И?",
        options: ["0", "1", "2"],
        correctAnswer: "1",
        hint: "ЛЫ-ЖИ - посчитай буквы И"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты освоил правило ЖИ-ШИ! 🏆"
    }
  },
  {
    title: "ЧА-ЩА пиши с А",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'fill',
        question: "Вставь букву: Ч__ЩА",
        correctAnswer: "А",
        hint: "Вспомни правило!"
      },
      {
        type: 'quiz',
        question: "Как правильно?",
        options: ["ЧЯСЫ", "ЧАСЫ"],
        correctAnswer: "ЧАСЫ",
        hint: "ЧА пиши с буквой А"
      },
      {
        type: 'find',
        question: "Найди слова с ЧА-ЩА:",
        options: ["ЧАЩА", "ДАЧА", "ТОВАРИЩ", "ЩУКА", "ЧУДО"],
        correctAnswer: ["ЧАЩА", "ДАЧА", "ТОВАРИЩ"],
        hint: "Ищи сочетания ЧА и ЩА"
      },
      {
        type: 'fill',
        question: "Вставь букву: Щ__КА",
        correctAnswer: "У",
        hint: "Это речная рыба с острыми зубами!"
      }
    ],
    reward: {
      stars: 3,
      message: "Замечательно! Ты знаешь правило ЧА-ЩА! ⭐"
    }
  },
  {
    title: "Слоги и ударение",
    subject: "Русский язык",
    icon: "BookOpen",
    color: "text-red-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько слогов в слове МАМА?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Хлопни в ладоши: МА-МА"
      },
      {
        type: 'order',
        question: "Расставь слоги по порядку: ЛИ-МА",
        correctAnswer: "МА-ЛИ",
        hint: "Это сладкая ягода"
      },
      {
        type: 'quiz',
        question: "Какой слог ударный в слове ШКОЛА?",
        options: ["ШКО", "ЛА"],
        correctAnswer: "ЛА",
        hint: "Произнеси слово и послушай!"
      },
      {
        type: 'find',
        question: "Выбери слова из 2 слогов:",
        options: ["ДОМ", "ВО-ДА", "СО-ЛНЦЕ", "КОТ", "МА-ШИ-НА"],
        correctAnswer: ["ВО-ДА"],
        hint: "Хлопни и посчитай"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты понимаешь слоги и ударение! 🌈"
    }
  },

  // ========== МАТЕМАТИКА ==========
  {
    title: "Числа 1, 2, 3",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Сколько яблок на картинке? 🍎🍎",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Посчитай внимательно!"
      },
      {
        type: 'order',
        question: "Расставь по порядку: 3, 1, 2",
        correctAnswer: "1, 2, 3",
        hint: "От меньшего к большему"
      },
      {
        type: 'quiz',
        question: "Какое число больше?",
        options: ["1", "2", "3"],
        correctAnswer: "3",
        hint: "Какое число последнее при счёте?"
      },
      {
        type: 'fill',
        question: "Какое число стоит между 1 и 3?",
        correctAnswer: "2",
        hint: "Посчитай: 1, ?, 3"
      }
    ],
    reward: {
      stars: 3,
      message: "Умница! Ты знаешь числа 1, 2, 3! 🔢"
    }
  },
  {
    title: "Сложение до 5",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "1 + 1 = ?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Один да ещё один..."
      },
      {
        type: 'quiz',
        question: "2 + 2 = ?",
        options: ["3", "4", "5"],
        correctAnswer: "4",
        hint: "Два и два вместе"
      },
      {
        type: 'fill',
        question: "3 + __ = 5",
        correctAnswer: "2",
        hint: "Сколько нужно добавить до пяти?"
      },
      {
        type: 'find',
        question: "Выбери верные равенства:",
        options: ["1+2=3", "2+3=4", "1+3=4", "2+2=5"],
        correctAnswer: ["1+2=3", "1+3=4"],
        hint: "Проверь каждое равенство"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты умеешь складывать! ➕"
    }
  },
  {
    title: "Вычитание до 5",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "3 - 1 = ?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "Было три, убрали один..."
      },
      {
        type: 'quiz',
        question: "5 - 2 = ?",
        options: ["2", "3", "4"],
        correctAnswer: "3",
        hint: "Пять без двух"
      },
      {
        type: 'fill',
        question: "4 - __ = 2",
        correctAnswer: "2",
        hint: "Сколько нужно убрать?"
      },
      {
        type: 'quiz',
        question: "У Маши 3 конфеты. Она съела 1. Сколько осталось?",
        options: ["1", "2", "3"],
        correctAnswer: "2",
        hint: "3 - 1 = ?"
      }
    ],
    reward: {
      stars: 3,
      message: "Молодец! Ты умеешь вычитать! ➖"
    }
  },
  {
    title: "Геометрические фигуры",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "У какой фигуры 4 угла?",
        options: ["Треугольник", "Квадрат", "Круг"],
        correctAnswer: "Квадрат",
        hint: "Квадрат имеет 4 угла"
      },
      {
        type: 'quiz',
        question: "Сколько углов у треугольника?",
        options: ["2", "3", "4"],
        correctAnswer: "3",
        hint: "Тре-угольник = три угла"
      },
      {
        type: 'find',
        question: "Выбери фигуры без углов:",
        options: ["Круг", "Овал", "Квадрат", "Треугольник"],
        correctAnswer: ["Круг", "Овал"],
        hint: "Какие фигуры можно катить?"
      },
      {
        type: 'quiz',
        question: "Какая фигура похожа на солнце?",
        options: ["Квадрат", "Круг", "Треугольник"],
        correctAnswer: "Круг",
        hint: "Солнце круглое!"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь геометрические фигуры! 🔷"
    }
  },
  {
    title: "Сравнение чисел",
    subject: "Математика",
    icon: "Calculator",
    color: "text-blue-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какое число больше: 5 или 3?",
        options: ["5", "3", "Они равны"],
        correctAnswer: "5",
        hint: "Посчитай от 1 до 5"
      },
      {
        type: 'quiz',
        question: "Поставь знак: 4 __ 4",
        options: [">", "<", "="],
        correctAnswer: "=",
        hint: "Числа одинаковые"
      },
      {
        type: 'fill',
        question: "Какое число меньше: 2 или 4?",
        correctAnswer: "2",
        hint: "2 идёт раньше при счёте"
      },
      {
        type: 'find',
        question: "Выбери верные неравенства:",
        options: ["3 > 2", "5 < 4", "2 = 2", "1 > 3"],
        correctAnswer: ["3 > 2", "2 = 2"],
        hint: "Проверь каждое сравнение"
      }
    ],
    reward: {
      stars: 3,
      message: "Замечательно! Ты умеешь сравнивать! ⚖️"
    }
  },

  // ========== ОКРУЖАЮЩИЙ МИР ==========
  {
    title: "Времена года",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какое время года идёт после зимы?",
        options: ["Лето", "Осень", "Весна"],
        correctAnswer: "Весна",
        hint: "Когда тает снег?"
      },
      {
        type: 'find',
        question: "Выбери приметы осени:",
        options: ["Листопад", "Снег", "Жаркое солнце", "Дожди", "Цветение"],
        correctAnswer: ["Листопад", "Дожди"],
        hint: "Что бывает осенью?"
      },
      {
        type: 'quiz',
        question: "В какое время года можно купаться в речке?",
        options: ["Зимой", "Весной", "Летом"],
        correctAnswer: "Летом",
        hint: "Когда тепло и солнечно?"
      },
      {
        type: 'order',
        question: "Расставь по порядку: Зима, Лето, Осень, Весна",
        correctAnswer: "Зима, Весна, Лето, Осень",
        hint: "Начни с зимы"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь времена года! 🍂"
    }
  },
  {
    title: "Домашние животные",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери домашних животных:",
        options: ["Корова", "Волк", "Кошка", "Лиса", "Собака"],
        correctAnswer: ["Корова", "Кошка", "Собака"],
        hint: "Кто живёт с человеком?"
      },
      {
        type: 'quiz',
        question: "Какое домашнее животное даёт молоко?",
        options: ["Кошка", "Корова", "Собака"],
        correctAnswer: "Корова",
        hint: "Большое животное с рогами"
      },
      {
        type: 'quiz',
        question: "Кто охраняет дом?",
        options: ["Кошка", "Собака", "Корова"],
        correctAnswer: "Собака",
        hint: "Это друг человека"
      },
      {
        type: 'quiz',
        question: "Кто ловит мышей?",
        options: ["Собака", "Корова", "Кошка"],
        correctAnswer: "Кошка",
        hint: "Это пушистое и мяукает"
      }
    ],
    reward: {
      stars: 3,
      message: "Супер! Ты знаешь домашних животных! 🐄"
    }
  },
  {
    title: "Дикие животные",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'find',
        question: "Выбери диких животных:",
        options: ["Медведь", "Корова", "Заяц", "Кошка", "Лиса"],
        correctAnswer: ["Медведь", "Заяц", "Лиса"],
        hint: "Кто живёт в лесу?"
      },
      {
        type: 'quiz',
        question: "Кто спит зимой в берлоге?",
        options: ["Заяц", "Медведь", "Лиса"],
        correctAnswer: "Медведь",
        hint: "Большой бурый зверь"
      },
      {
        type: 'quiz',
        question: "У кого длинные уши?",
        options: ["Медведь", "Заяц", "Волк"],
        correctAnswer: "Заяц",
        hint: "Этот зверёк прыгает"
      },
      {
        type: 'quiz',
        question: "Кто самый хищный в лесу?",
        options: ["Заяц", "Медведь", "Волк"],
        correctAnswer: "Волк",
        hint: "Серый и страшный"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты знаешь лесных жителей! 🐻"
    }
  },
  {
    title: "Правила дорожного движения",
    subject: "Окружающий мир",
    icon: "Globe",
    color: "text-green-400",
    tasks: [
      {
        type: 'quiz',
        question: "Какой цвет светофора разрешает идти?",
        options: ["Красный", "Жёлтый", "Зелёный"],
        correctAnswer: "Зелёный",
        hint: "Зелёный - можно идти!"
      },
      {
        type: 'quiz',
        question: "На какой сигнал светофора нужно остановиться?",
        options: ["Зелёный", "Красный", "Жёлтый"],
        correctAnswer: "Красный",
        hint: "Красный - стой!"
      },
      {
        type: 'find',
        question: "Где можно переходить дорогу?",
        options: ["На зелёный свет", "Где захочется", "По зебре", "Между машинами"],
        correctAnswer: ["На зелёный свет", "По зебре"],
        hint: "Безопасные места"
      },
      {
        type: 'quiz',
        question: "Что обозначает жёлтый свет светофора?",
        options: ["Иди", "Стой", "Приготовься"],
        correctAnswer: "Приготовься",
        hint: "Внимание! Скоро смена сигнала"
      }
    ],
    reward: {
      stars: 3,
      message: "Умница! Ты знаешь правила безопасности! 🚦"
    }
  },

  // ========== ЛИТЕРАТУРНОЕ ЧТЕНИЕ ==========
  {
    title: "Сказка «Колобок»",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Кто испёк Колобка?",
        options: ["Дед", "Бабка", "Дед и Бабка"],
        correctAnswer: "Дед и Бабка",
        hint: "Вспомни начало сказки"
      },
      {
        type: 'order',
        question: "Кого встретил Колобок по порядку?",
        options: ["Заяц, Волк, Медведь, Лиса", "Медведь, Лиса, Заяц, Волк"],
        correctAnswer: "Заяц, Волк, Медведь, Лиса",
        hint: "Вспомни сказку"
      },
      {
        type: 'quiz',
        question: "Кто съел Колобка?",
        options: ["Заяц", "Волк", "Лиса"],
        correctAnswer: "Лиса",
        hint: "Хитрая рыжая плутовка"
      },
      {
        type: 'find',
        question: "Кто НЕ встретил Колобка?",
        options: ["Заяц", "Волк", "Ёжик", "Медведь", "Белка"],
        correctAnswer: ["Ёжик", "Белка"],
        hint: "Кого нет в сказке?"
      }
    ],
    reward: {
      stars: 3,
      message: "Прекрасно! Ты знаешь сказку! 📖"
    }
  },
  {
    title: "Сказка «Теремок»",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Кто первым пришёл в теремок?",
        options: ["Мышка", "Лягушка", "Зайчик"],
        correctAnswer: "Мышка",
        hint: "Самый маленький зверёк"
      },
      {
        type: 'find',
        question: "Кто жил в теремке?",
        options: ["Мышка", "Лягушка", "Зайчик", "Лисичка", "Волчок", "Медведь"],
        correctAnswer: ["Мышка", "Лягушка", "Зайчик", "Лисичка", "Волчок"],
        hint: "Медведь сломал теремок"
      },
      {
        type: 'quiz',
        question: "Кто сломал теремок?",
        options: ["Зайчик", "Лисичка", "Медведь"],
        correctAnswer: "Медведь",
        hint: "Самый большой и тяжёлый"
      },
      {
        type: 'quiz',
        question: "Какая была мышка в сказке?",
        options: ["Серая", "Белая", "Коричневая"],
        correctAnswer: "Серая",
        hint: "Какого цвета обычно мышки?"
      }
    ],
    reward: {
      stars: 3,
      message: "Отлично! Ты помнишь сказку! 🏠"
    }
  },
  {
    title: "Стихи А.Л. Барто",
    subject: "Литературное чтение",
    icon: "BookOpenText",
    color: "text-purple-400",
    tasks: [
      {
        type: 'quiz',
        question: "Про кого стихотворение «Уронили мишку на пол...»?",
        options: ["Кота", "Медведя", "Зайку"],
        correctAnswer: "Медведя",
        hint: "Мишка - это медвежонок"
      },
      {
        type: 'quiz',
        question: "Кто «оставлен на скамейке» в стихах Барто?",
        options: ["Мишка", "Зайка", "Бычок"],
        correctAnswer: "Зайка",
        hint: "Зайку бросила хозяйка"
      },
      {
        type: 'find',
        question: "Какие игрушки есть в стихах Барто?",
        options: ["Мишка", "Зайка", "Кукла", "Бычок", "Мяч", "Машина"],
        correctAnswer: ["Мишка", "Зайка", "Бычок", "Мяч"],
        hint: "Вспомни стихи"
      },
      {
        type: 'quiz',
        question: "Как зовут автора стихов «Игрушки»?",
        options: ["Маршак", "Барто", "Чуковский"],
        correctAnswer: "Барто",
        hint: "Агния Львовна"
      }
    ],
    reward: {
      stars: 3,
      message: "Замечательно! Ты знаешь стихи! 📚"
    }
  },

  // ========== ИНОСТРАННЫЙ ЯЗЫК ==========
  {
    title: "Hello! Привет!",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Как сказать «Привет» по-английски?",
        options: ["Goodbye", "Hello", "Thanks"],
        correctAnswer: "Hello",
        hint: "Это самое популярное приветствие"
      },
      {
        type: 'match',
        question: "Соедини: Hello - это...",
        options: ["Привет", "Пока", "Спасибо"],
        correctAnswer: "Привет",
        hint: "Hello = Привет"
      },
      {
        type: 'quiz',
        question: "Как ещё можно поздороваться?",
        options: ["Hi", "Bye", "No"],
        correctAnswer: "Hi",
        hint: "Это короткое приветствие"
      },
      {
        type: 'find',
        question: "Выбери приветствия:",
        options: ["Hello", "Hi", "Goodbye", "Bye", "Thanks"],
        correctAnswer: ["Hello", "Hi"],
        hint: "Приветствия = Greetings"
      }
    ],
    reward: {
      stars: 3,
      message: "Great! Отлично! Ты знаешь приветствия! 👋"
    }
  },
  {
    title: "Цвета по-английски",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Red - это какой цвет?",
        options: ["Синий", "Красный", "Зелёный"],
        correctAnswer: "Красный",
        hint: "Red = Красный"
      },
      {
        type: 'quiz',
        question: "Как будет «синий» по-английски?",
        options: ["Red", "Blue", "Green"],
        correctAnswer: "Blue",
        hint: "Blue = Синий"
      },
      {
        type: 'find',
        question: "Выбери названия цветов:",
        options: ["Red", "Cat", "Blue", "Dog", "Green", "Yellow"],
        correctAnswer: ["Red", "Blue", "Green", "Yellow"],
        hint: "Colours = Цвета"
      },
      {
        type: 'quiz',
        question: "Какого цвета трава?",
        options: ["Red", "Blue", "Green"],
        correctAnswer: "Green",
        hint: "Трава зелёная"
      }
    ],
    reward: {
      stars: 3,
      message: "Wonderful! Ты знаешь цвета! 🎨"
    }
  },
  {
    title: "Числа 1-5",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "One - это какое число?",
        options: ["Один", "Два", "Три"],
        correctAnswer: "Один",
        hint: "One = 1"
      },
      {
        type: 'quiz',
        question: "Как будет «три» по-английски?",
        options: ["One", "Two", "Three"],
        correctAnswer: "Three",
        hint: "Three = 3"
      },
      {
        type: 'order',
        question: "Расставь по порядку: Three, One, Two",
        correctAnswer: "One, Two, Three",
        hint: "От 1 до 3"
      },
      {
        type: 'quiz',
        question: "Five - это?",
        options: ["4", "5", "6"],
        correctAnswer: "5",
        hint: "Five = 5"
      }
    ],
    reward: {
      stars: 3,
      message: "Excellent! Ты знаешь числа! 🔢"
    }
  },
  {
    title: "Животные",
    subject: "Иностранный язык",
    icon: "Languages",
    color: "text-pink-400",
    tasks: [
      {
        type: 'quiz',
        question: "Cat - это?",
        options: ["Собака", "Кошка", "Птица"],
        correctAnswer: "Кошка",
        hint: "Cat = Кошка"
      },
      {
        type: 'quiz',
        question: "Как будет «собака» по-английски?",
        options: ["Cat", "Dog", "Bird"],
        correctAnswer: "Dog",
        hint: "Dog = Собака"
      },
      {
        type: 'find',
        question: "Выбери названия животных:",
        options: ["Cat", "Red", "Dog", "Blue", "Bird", "Fish"],
        correctAnswer: ["Cat", "Dog", "Bird", "Fish"],
        hint: "Animals = Животные"
      },
      {
        type: 'quiz',
        question: "Fish - это?",
        options: ["Птица", "Рыба", "Кошка"],
        correctAnswer: "Рыба",
        hint: "Fish живёт в воде"
      }
    ],
    reward: {
      stars: 3,
      message: "Great job! Ты знаешь животных! 🐱"
    }
  }
];

export const getGamesBySubject = (subject: string): GameLesson[] => {
  return firstGradeGames.filter(game => game.subject === subject);
};

export const getGameByTitle = (title: string): GameLesson | undefined => {
  return firstGradeGames.find(game => game.title === title);
};
